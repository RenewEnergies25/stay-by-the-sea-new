export const SEED_CONTENT = {
  hero: {
    title: 'Seaside luxury for up to 14 guests in Blackpool',
    subtitle: '7 double beds · 2 bathrooms · air con · underfloor heating · smart TVs · modern kitchen · 2 private parking spaces',
    description: 'Welcome to Stay By The Sea – a newly refurbished modern apartment sleeping up to 14 guests. Perfect for families, groups, and seaside getaways, it blends style, comfort, and unbeatable location. Just 50m from the beach, walk to Blackpool Pleasure Beach and top attractions. Private parking for 2 cars. Book your stay today for the ultimate Blackpool escape!',
  },
  property: {
    title: 'Modern Coastal Comfort',
    description: 'Our thoughtfully designed property combines contemporary luxury with seaside charm. Every detail has been carefully considered to ensure your stay is memorable. Inside, you\'ll find LED mood lighting throughout, air conditioning in every bedroom, underfloor heating across the apartment, two sleek bathrooms, Smart TVs in every bedroom plus two in the living space, and a fully equipped kitchen with coffee machine & washer-dryer.',
    highlights: [
      'LED mood lighting throughout',
      'Seven comfortable double beds across multiple bedrooms',
      'Fully equipped kitchen with coffee machine & washer-dryer',
      'Two sleek bathrooms',
      'Air conditioning in every bedroom & underfloor heating across the apartment',
      'Smart TVs in every bedroom, plus two in the living space',
    ],
  },
  location: {
    title: 'Prime South Shore Location',
    description: 'Stay By The Sea sits in an unbeatable location at 373 Promenade 1b and 1c Alexandra Road, right on Blackpool\'s famous Golden Mile — you\'re just seconds from the promenade and beach, putting sun, sand, and sea at your doorstep. Take a short stroll and you\'ll be at South Pier and Central Pier, each with amusements, rides, arcades, cafés and seaside views. For thrills close by, Blackpool Pleasure Beach is within walking distance, and if the weather turns, dive into Sandcastle Waterpark or explore SEA LIFE Blackpool and Madame Tussauds. Culture-lovers will enjoy the historic Blackpool Tower and Winter Gardens, plus Stanley Park with its Italian gardens, boating lake, model village and open green spaces for relaxed afternoons. For dining, local favourites include Marco\'s New York Italian Restaurant offering a blend of comfort food and fine dining, Le Carter Blanche at The Chatwal Boutique Hotel, plus Efe\'s Restaurant, Stefani\'s Pizzeria and more just around the corner. For quick bites, McDonald\'s is just a 4-minute walk. If you fancy something more relaxed, cafés, bars and pubs line the nearby streets, and shops are easily accessible. Everything you need—entertainment, food, beach, and views.',
  },
  guestInfo: {
    checkIn: 'Check-in is from 4:00 PM. We\'ll send you detailed arrival instructions 24 hours before your stay.',
    checkOut: 'Check-out is by 11:00 AM. Please ensure all keys are returned and the property is left tidy.',
    wifi: 'Connect to "StayByTheSea_Guest" with password provided in your welcome message.',
    parking: 'Two dedicated parking spaces are available directly outside the property. Additional public parking is available nearby if needed.',
  },
};

export const GALLERY_IMAGES = [
  {
    src: 'https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080',
    alt: 'Stay by the Sea property view',
    caption: 'Modern lounge and kitchen area',
  },
  {
    src: 'https://images.pexels.com/photos/271618/pexels-photo-271618.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080',
    alt: 'Stay by the Sea property view',
    caption: 'Luxurious double bedroom',
  },
  {
    src: 'https://images.pexels.com/photos/1454806/pexels-photo-1454806.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080',
    alt: 'Stay by the Sea property view',
    caption: 'Modern bathroom with sleek fixtures',
  },
  {
    src: 'https://images.pexels.com/photos/271624/pexels-photo-271624.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080',
    alt: 'Stay by the Sea property view',
    caption: 'Stylish double bedroom with comfort',
  },
  {
    src: 'https://images.pexels.com/photos/1454804/pexels-photo-1454804.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080',
    alt: 'Stay by the Sea property view',
    caption: 'Welcoming entrance hallway',
  },
  {
    src: 'https://images.pexels.com/photos/271743/pexels-photo-271743.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080',
    alt: 'Stay by the Sea property view',
    caption: 'Cozy third double bedroom',
  },
  {
    src: 'https://images.pexels.com/photos/271816/pexels-photo-271816.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080',
    alt: 'Stay by the Sea property view',
    caption: 'Fourth double bedroom with elegant decor',
  },
  {
    src: 'https://images.pexels.com/photos/271897/pexels-photo-271897.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080',
    alt: 'Stay by the Sea property view',
    caption: 'Fifth double bedroom with coastal theme',
  },
  {
    src: 'https://images.pexels.com/photos/271715/pexels-photo-271715.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080',
    alt: 'Stay by the Sea property view',
    caption: 'Sixth double bedroom with modern amenities',
  },
  {
    src: 'https://images.pexels.com/photos/271696/pexels-photo-271696.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080',
    alt: 'Stay by the Sea property view',
    caption: 'Seventh double bedroom with luxury finishes',
  },
  {
    src: 'https://images.pexels.com/photos/1454805/pexels-photo-1454805.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080',
    alt: 'Stay by the Sea property view',
    caption: 'Second modern bathroom',
  },
  {
    src: 'https://images.pexels.com/photos/1396122/pexels-photo-1396122.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080',
    alt: 'Stay by the Sea property view',
    caption: 'Exterior view of the property',
  },
  {
    src: 'https://images.pexels.com/photos/164634/pexels-photo-164634.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080',
    alt: 'Stay by the Sea property view',
    caption: 'Private parking area',
  },
  {
    src: 'https://images.pexels.com/photos/1032650/pexels-photo-1032650.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080',
    alt: 'Stay by the Sea property view',
    caption: 'Nearby Blackpool beach view',
  },
  {
    src: 'https://images.pexels.com/photos/1032649/pexels-photo-1032649.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080',
    alt: 'Stay by the Sea property view',
    caption: 'Blackpool Pleasure Beach view',
  },
  {
    src: 'https://images.pexels.com/photos/1032648/pexels-photo-1032648.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080',
    alt: 'Stay by the Sea property view',
    caption: 'Panoramic view of Blackpool\'s Golden Mile',
  },
  {
    src: 'https://images.pexels.com/photos/1032647/pexels-photo-1032647.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080',
    alt: 'Stay by the Sea property view',
    caption: 'Sunset view from the property',
  },
  {
    src: 'https://images.pexels.com/photos/1571463/pexels-photo-1571463.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080',
    alt: 'Stay by the Sea property view',
    caption: 'Dining area for group meals',
  },
  {
    src: 'https://images.pexels.com/photos/1571468/pexels-photo-1571468.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080',
    alt: 'Stay by the Sea property view',
    caption: 'Living room with comfortable seating',
  },
  {
    src: 'https://images.pexels.com/photos/1571452/pexels-photo-1571452.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080',
    alt: 'Stay by the Sea property view',
    caption: 'Detailed view of modern kitchen appliances',
  },
  {
    src: 'https://images.pexels.com/photos/271618/pexels-photo-271618.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080',
    alt: 'Stay by the Sea property view',
    caption: 'Air conditioning units for comfort',
  },
  {
    src: 'https://images.pexels.com/photos/271624/pexels-photo-271624.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080',
    alt: 'Stay by the Sea property view',
    caption: 'Underfloor heating system',
  },
  {
    src: 'https://images.pexels.com/photos/271743/pexels-photo-271743.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080',
    alt: 'Stay by the Sea property view',
    caption: 'Smart TVs in bedrooms',
  },
  {
    src: 'https://images.pexels.com/photos/271816/pexels-photo-271816.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080',
    alt: 'Stay by the Sea property view',
    caption: 'Overview of the entire property',
  },
  {
    src: 'https://images.pexels.com/photos/271897/pexels-photo-271897.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080',
    alt: 'Stay by the Sea property view',
    caption: 'Luxury linens and bedding',
  },
  {
    src: 'https://images.pexels.com/photos/271715/pexels-photo-271715.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080',
    alt: 'Stay by the Sea property view',
    caption: 'Washing machine and dryer facilities',
  },
  {
    src: 'https://images.pexels.com/photos/271696/pexels-photo-271696.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080',
    alt: 'Stay by the Sea property view',
    caption: 'Welcoming entrance to the property',
  },
];

export const FAQ_DATA = [
  {
    question: 'Why should I book directly on your website?',
    answer: 'When you book directly through our website, you save 5% compared to booking through third-party platforms like Airbnb or Booking.com. You also get instant confirmation, direct communication with us, and the best customer service experience. We\'re committed to offering our guests the best value when they book direct.',
  },
  {
    question: 'What is included in the booking?',
    answer: 'Your booking includes accommodation for up to 14 guests, all linens and towels, Wi-Fi, parking for 2 cars, and access to all amenities including air conditioning, underfloor heating, and smart TVs.',
  },
  {
    question: 'How do I check in?',
    answer: 'We offer self-check-in with detailed instructions sent 24 hours before arrival. You\'ll receive door codes and a welcome guide via SMS and email.',
  },
  {
    question: 'Is parking available?',
    answer: 'Yes, we provide 2 dedicated parking spaces directly outside the property. Additional public parking is available nearby if you have more than 2 vehicles.',
  },
  {
    question: 'Can I cancel or modify my booking?',
    answer: 'Cancellation and modification policies depend on your booking type and timing. Please refer to your booking confirmation or contact us directly for specific terms.',
  },
  {
    question: 'Are pets allowed?',
    answer: 'Unfortunately, we do not allow pets to ensure the comfort of all guests and maintain our high standards of cleanliness.',
  },
  {
    question: 'What attractions are nearby?',
    answer: 'We\'re perfectly located near Blackpool\'s top attractions: Pleasure Beach (15 min walk), South Pier (5 min walk), Blackpool Tower (20 min walk), and the tram stop is just 3 minutes away.',
  },
];