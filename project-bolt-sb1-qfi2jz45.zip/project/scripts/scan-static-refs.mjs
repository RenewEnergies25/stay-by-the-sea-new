// scripts/scan-static-refs.mjs
import fs from 'fs';
import path from 'path';

const roots = ['app', 'pages', 'components', 'src', 'public'];

const needles = [
  '/_next/static/',
  'vendors.css',
  'main-app.js',
  'webpack.js',
  '.hot-update.'
];

const hits = [];

function walk(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, entry.name);
    if (entry.isDirectory()) walk(p);
    else if (/\.(js|ts|tsx|jsx|html|css|mdx|json)$/i.test(entry.name)) {
      const txt = fs.readFileSync(p, 'utf8');
      for (const n of needles) {
        if (txt.includes(n)) hits.push({ file: p, needle: n });
      }
    }
  }
}

for (const r of roots) {
  if (fs.existsSync(r)) walk(r);
}

if (!hits.length) {
  console.log('✅ No hard-coded _next/static references found.');
} else {
  console.log('❌ Hard-coded references found:\n');
  for (const h of hits) {
    console.log('-', h.needle, 'in', h.file);
  }
  process.exitCode = 1;
}