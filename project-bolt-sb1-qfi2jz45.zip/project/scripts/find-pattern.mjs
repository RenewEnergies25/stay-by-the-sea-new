// scripts/find-pattern.mjs
import fs from "fs";
import path from "path";

const roots = ["app", "components", "lib", "pages", "src"];
const needles = [
  "tailwind.config",                     // import of your config file
  "from 'tailwindcss'",                  // type-only imports in runtime code
  'from "tailwindcss"',                  // double-quote variant
];

function* walk(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      yield* walk(p);
    } else {
      if (/\.(t|j)sx?$/.test(entry.name)) yield p;
    }
  }
}

for (const root of roots) {
  if (!fs.existsSync(root)) continue;
  for (const file of walk(root)) {
    const text = fs.readFileSync(file, "utf8");
    for (const needle of needles) {
      if (text.includes(needle)) {
        console.log(`${file} :: contains :: ${needle}`);
      }
    }
  }
}