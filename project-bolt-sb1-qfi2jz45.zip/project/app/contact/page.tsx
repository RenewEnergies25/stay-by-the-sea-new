import type { Metadata } from 'next';
import { Hero } from '@/components/ui/Hero';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { PROPERTY_CONFIG } from '@/lib/constants';
import { GALLERY_IMAGES } from '@/data/seed';
import Link from 'next/link';
import { Phone, Mail, MapPin, MessageCircle, Clock, Calendar } from 'lucide-react';

export const metadata: Metadata = {
  title: 'Contact Us | Get in Touch About Your Stay',
  description: 'Contact Stay by the Sea for bookings, questions, or support. Phone, email, WhatsApp available. Quick response guaranteed for your Blackpool holiday rental.',
  alternates: {
    canonical: '/contact',
  },
};

export default function ContactPage() {
  return (
    <>
      {/* Hero Section */}
      <Hero
        title="Get in Touch"
        subtitle="We're here to help with your perfect seaside getaway"
        backgroundImage={GALLERY_IMAGES[4].src}
        showCTAs={false}
        height="medium"
      />

      {/* Contact Information */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-playfair font-bold text-navy mb-6">
              How Can We Help?
            </h2>
            <p className="text-lg text-navy/70 max-w-2xl mx-auto">
              Whether you have questions about booking, need assistance during your stay, or want to know more about our property, we're here to help.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Phone Contact */}
            <Card className="text-center border-0 shadow-lg hover:shadow-xl transition-shadow">
              <CardHeader>
                <div className="w-16 h-16 bg-teal/10 rounded-2xl mx-auto flex items-center justify-center mb-4">
                  <Phone className="h-8 w-8 text-teal" />
                </div>
                <CardTitle className="text-xl font-playfair text-navy">Call Us</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-navy/70">
                  Speak directly with our team for immediate assistance
                </p>
                <div className="space-y-2">
                  <p className="font-semibold text-navy">{PROPERTY_CONFIG.contact.phone}</p>
                  <p className="text-sm text-navy/60">Available 9 AM - 9 PM daily</p>
                </div>
                <a href={`tel:${PROPERTY_CONFIG.contact.phone}`}>
                  <Button className="btn-secondary w-full">
                    <Phone className="h-4 w-4 mr-2" />
                    Call Now
                  </Button>
                </a>
              </CardContent>
            </Card>

            {/* Email Contact */}
            <Card className="text-center border-0 shadow-lg hover:shadow-xl transition-shadow">
              <CardHeader>
                <div className="w-16 h-16 bg-coral/10 rounded-2xl mx-auto flex items-center justify-center mb-4">
                  <Mail className="h-8 w-8 text-coral" />
                </div>
                <CardTitle className="text-xl font-playfair text-navy">Email Us</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-navy/70">
                  Send us a detailed message and we'll respond within 2 hours
                </p>
                <div className="space-y-2">
                  <p className="font-semibold text-navy break-all">{PROPERTY_CONFIG.contact.email}</p>
                  <p className="text-sm text-navy/60">Response within 2 hours</p>
                </div>
                <a href={`mailto:${PROPERTY_CONFIG.contact.email}`}>
                  <Button className="btn-secondary w-full">
                    <Mail className="h-4 w-4 mr-2" />
                    Send Email
                  </Button>
                </a>
              </CardContent>
            </Card>

            {/* WhatsApp Contact */}
            <Card className="text-center border-0 shadow-lg hover:shadow-xl transition-shadow">
              <CardHeader>
                <div className="w-16 h-16 bg-navy/10 rounded-2xl mx-auto flex items-center justify-center mb-4">
                  <MessageCircle className="h-8 w-8 text-navy" />
                </div>
                <CardTitle className="text-xl font-playfair text-navy">WhatsApp</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-navy/70">
                  Quick messages and instant responses via WhatsApp
                </p>
                <div className="space-y-2">
                  <p className="font-semibold text-navy">Instant messaging</p>
                  <p className="text-sm text-navy/60">Usually online 8 AM - 10 PM</p>
                </div>
                <a 
                  href={PROPERTY_CONFIG.contact.whatsapp}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <Button className="btn-secondary w-full">
                    <MessageCircle className="h-4 w-4 mr-2" />
                    WhatsApp Us
                  </Button>
                </a>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Property Address */}
      <section className="py-20 bg-beige/30">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-playfair font-bold text-navy mb-6">
              Visit Us
            </h2>
            <p className="text-lg text-navy/70">
              Our property is located in the heart of Blackpool's South Shore
            </p>
          </div>

          <Card className="border-0 shadow-lg">
            <CardContent className="p-8">
              <div className="flex flex-col md:flex-row items-center md:items-start space-y-6 md:space-y-0 md:space-x-8">
                <div className="w-16 h-16 bg-teal/10 rounded-2xl flex items-center justify-center flex-shrink-0">
                  <MapPin className="h-8 w-8 text-teal" />
                </div>
                <div className="text-center md:text-left flex-grow">
                  <h3 className="text-xl font-playfair font-semibold text-navy mb-4">
                    Stay by the Sea
                  </h3>
                  <address className="not-italic text-navy/70 mb-6">
                    {PROPERTY_CONFIG.address.line1}<br />
                    {PROPERTY_CONFIG.address.city} {PROPERTY_CONFIG.address.postcode}<br />
                    United Kingdom
                  </address>
                  <div className="flex flex-col sm:flex-row gap-4">
                    <Link href="/location">
                      <Button className="btn-secondary">
                        <MapPin className="h-4 w-4 mr-2" />
                        View on Map
                      </Button>
                    </Link>
                    <a
                      href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
                        `${PROPERTY_CONFIG.address.line1}, ${PROPERTY_CONFIG.address.city} ${PROPERTY_CONFIG.address.postcode}`
                      )}`}
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <Button variant="outline" className="btn-secondary">
                        Get Directions
                      </Button>
                    </a>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-playfair font-bold text-navy mb-6">
              Quick Answers
            </h2>
            <p className="text-lg text-navy/70">
              Common questions we receive from guests
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center space-x-3">
                  <Clock className="h-6 w-6 text-teal" />
                  <span>Check-in Times</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-navy/70 mb-4">
                  Check-in is from 4:00 PM onwards. We'll send you detailed arrival instructions 24 hours before your stay.
                </p>
                <p className="text-sm text-teal font-medium">Self check-in available</p>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center space-x-3">
                  <Calendar className="h-6 w-6 text-teal" />
                  <span>Booking Changes</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-navy/70 mb-4">
                  Need to modify your booking? Contact us as soon as possible and we'll do our best to accommodate changes.
                </p>
                <p className="text-sm text-teal font-medium">Flexible policies available</p>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center space-x-3">
                  <MapPin className="h-6 w-6 text-teal" />
                  <span>Parking</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-navy/70 mb-4">
                  Two dedicated parking spaces are included. Additional public parking is available nearby if needed.
                </p>
                <p className="text-sm text-teal font-medium">Free private parking</p>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center space-x-3">
                  <Phone className="h-6 w-6 text-teal" />
                  <span>Emergency Contact</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-navy/70 mb-4">
                  For urgent matters during your stay, call us directly. We're available for emergencies 24/7.
                </p>
                <p className="text-sm text-teal font-medium">24/7 emergency support</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-navy text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-playfair font-bold mb-6">
            Ready to Book Your Stay?
          </h2>
          <p className="text-xl text-beige mb-8 max-w-2xl mx-auto">
            Don't wait - secure your perfect seaside getaway today. Our calendar fills up quickly, especially during peak season.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link href="/book">
              <Button className="bg-coral hover:bg-coral/90 text-white px-10 py-4 text-lg rounded-2xl">
                <Calendar className="h-5 w-5 mr-2" />
                Check Availability
              </Button>
            </Link>
            <a href={`tel:${PROPERTY_CONFIG.contact.phone}`}>
              <Button variant="outline" className="border-beige text-beige hover:bg-beige hover:text-navy px-8 py-4 text-lg rounded-2xl">
                <Phone className="h-5 w-5 mr-2" />
                Call to Book
              </Button>
            </a>
          </div>
        </div>
      </section>
    </>
  );
}