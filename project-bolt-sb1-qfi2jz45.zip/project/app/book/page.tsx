// app/book/page.tsx
import type { Metadata } from 'next';
import dynamic from 'next/dynamic';
import { Hero } from '@/components/ui/Hero';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { GALLERY_IMAGES } from '@/data/seed';
import { PROPERTY_CONFIG } from '@/lib/constants';
import { Shield, Clock, Car, Users, Phone, Mail, Percent } from 'lucide-react';
import { BookingPlatforms } from '@/components/BookingPlatforms';

const SmoobuBookingScript = dynamic(() => import('@/components/SmoobuBookingScript').then(mod => ({ default: mod.SmoobuBookingScript })), {
  ssr: false,
  loading: () => <div className="flex items-center justify-center py-12"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-coral"></div></div>
});

const SITE_URL = process.env.NEXT_PUBLIC_PROPERTY_URL ?? '';

export const metadata: Metadata = {
  title: 'Book Your Stay | Live Availability & Secure Payments',
  description:
    'Check live availability and book Stay by the Sea in Blackpool. Secure card payments via Stripe or PayPal. Instant confirmation.',
  alternates: {
    canonical: SITE_URL ? `${SITE_URL.replace(/\/$/, '')}/book` : '/book',
  },
};

const jsonLd = {
  '@context': 'https://schema.org',
  '@type': 'FAQPage',
  mainEntity: [
    {
      '@type': 'Question',
      name: 'What payment methods do you accept?',
      acceptedAnswer: {
        '@type': 'Answer',
        text:
          'We accept all major credit cards, debit cards, and PayPal through our secure payment system.',
      },
    },
    {
      '@type': 'Question',
      name: 'When will I receive confirmation?',
      acceptedAnswer: {
        '@type': 'Answer',
        text: 'You will receive instant confirmation via email once your booking is complete.',
      },
    },
    {
      '@type': 'Question',
      name: 'What are the check-in and check-out times?',
      acceptedAnswer: {
        '@type': 'Answer',
        text: 'Check-in is from 15:00–18:00 and check-out is by 10:00.',
      },
    },
  ],
};

export default function BookPage() {
  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />

      {/* Hero Section */}
      <Hero
        title="Book Your Stay"
        subtitle="Live availability, instant confirmation, and secure payments"
        backgroundImage={GALLERY_IMAGES?.[0]?.src}
        showCTAs={false}
        height="medium"
      />

      {/* Direct Booking Discount Banner */}
      <section className="bg-gradient-to-r from-coral to-coral/90 py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-center justify-center gap-4 text-white text-center md:text-left">
            <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center flex-shrink-0">
              <Percent className="h-8 w-8 text-white" />
            </div>
            <div>
              <h3 className="text-2xl font-playfair font-bold mb-1">
                Save 5% When You Book Direct
              </h3>
              <p className="text-white/90 text-lg">
                Skip the platform fees and enjoy our best rates by booking directly on our website
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Trust Indicators */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-5 gap-8">
            <Card className="text-center border-0 shadow-lg relative overflow-hidden">
              <div className="absolute top-2 right-2 bg-coral text-white px-2 py-1 rounded-full text-xs font-bold">
                5% OFF
              </div>
              <CardContent className="pt-8">
                <div className="w-16 h-16 bg-coral/10 rounded-2xl mx-auto flex items-center justify-center mb-4">
                  <Percent className="h-8 w-8 text-coral" />
                </div>
                <h3 className="font-semibold text-navy mb-2">Best Price Direct</h3>
                <p className="text-sm text-navy/70">5% cheaper than other platforms</p>
              </CardContent>
            </Card>

            <Card className="text-center border-0 shadow-lg">
              <CardContent className="pt-8">
                <div className="w-16 h-16 bg-teal/10 rounded-2xl mx-auto flex items-center justify-center mb-4">
                  <Shield className="h-8 w-8 text-teal" />
                </div>
                <h3 className="font-semibold text-navy mb-2">Secure Payments</h3>
                <p className="text-sm text-navy/70">SSL encrypted via Stripe &amp; PayPal</p>
              </CardContent>
            </Card>

            <Card className="text-center border-0 shadow-lg">
              <CardContent className="pt-8">
                <div className="w-16 h-16 bg-coral/10 rounded-2xl mx-auto flex items-center justify-center mb-4">
                  <Clock className="h-8 w-8 text-coral" />
                </div>
                <h3 className="font-semibold text-navy mb-2">Instant Confirmation</h3>
                <p className="text-sm text-navy/70">Immediate booking confirmation via email</p>
              </CardContent>
            </Card>

            <Card className="text-center border-0 shadow-lg">
              <CardContent className="pt-8">
                <div className="w-16 h-16 bg-navy/10 rounded-2xl mx-auto flex items-center justify-center mb-4">
                  <Users className="h-8 w-8 text-navy" />
                </div>
                <h3 className="font-semibold text-navy mb-2">Sleeps 14</h3>
                <p className="text-sm text-navy/70">7 double bedrooms, 2 bathrooms</p>
              </CardContent>
            </Card>

            <Card className="text-center border-0 shadow-lg">
              <CardContent className="pt-8">
                <div className="w-16 h-16 bg-beige/50 rounded-2xl mx-auto flex items-center justify-center mb-4">
                  <Car className="h-8 w-8 text-navy" />
                </div>
                <h3 className="font-semibold text-navy mb-2">Free Parking</h3>
                <p className="text-sm text-navy/70">Two private parking spaces included</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Booking Widget */}
      <section className="py-20 bg-beige/30">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-playfair font-bold text-navy mb-4">
              Check Availability &amp; Book
            </h2>
            <div className="inline-flex items-center gap-2 bg-coral/10 text-coral px-6 py-3 rounded-full text-base font-semibold mb-4">
              <Percent className="h-5 w-5" />
              <span>Booking directly saves you 5%</span>
            </div>
            <p className="text-lg text-navy/70 max-w-2xl mx-auto">
              Select your dates and see live availability. Secure your perfect seaside getaway
              today.
            </p>
          </div>

          {/* Smoobu Booking Widget */}
          <div className="w-full rounded-2xl shadow-2xl overflow-hidden bg-white">
            <div className="p-8">
              <SmoobuBookingScript />
            </div>
          </div>
        </div>
      </section>

      {/* Booking Platforms */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <BookingPlatforms variant="full" />
        </div>
      </section>

      {/* Good to Know Section */}
      <section className="py-20 bg-beige/30">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-playfair font-bold text-navy mb-6">
              Good to Know
            </h2>
            <p className="text-lg text-navy/70">Important information for your booking and stay</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center space-x-3">
                  <Clock className="h-6 w-6 text-teal" />
                  <span>Check-in &amp; Check-out</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <p className="text-navy/70">
                  <strong>Check-in:</strong> 15:00–18:00
                  <br />
                  <strong>Check-out:</strong> 10:00
                  <br />
                  <strong>Self check-in:</strong> Door codes provided 24 hours before arrival
                </p>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center space-x-3">
                  <Users className="h-6 w-6 text-coral" />
                  <span>Accommodation Details</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <p className="text-navy/70">
                  <strong>Sleeps:</strong> Up to 14 guests
                  <br />
                  <strong>Bedrooms:</strong> 7 double bedrooms
                  <br />
                  <strong>Bathrooms:</strong> 2 modern bathrooms
                </p>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center space-x-3">
                  <Car className="h-6 w-6 text-navy" />
                  <span>Parking &amp; Location</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <p className="text-navy/70">
                  <strong>Parking:</strong> Two private parking spaces on site
                  <br />
                  <strong>Location:</strong> South Shore, Blackpool
                  <br />
                  <strong>Beach:</strong> 50 yards from your door
                </p>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center space-x-3">
                  <Shield className="h-6 w-6 text-teal" />
                  <span>Booking &amp; Payments</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <p className="text-navy/70">
                  <strong>Payment:</strong> Secure card payments via Stripe or PayPal
                  <br />
                  <strong>Confirmation:</strong> Instant email confirmation
                  <br />
                  <strong>Support:</strong> 24/7 customer service available
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Contact Support */}
      <section className="py-20 bg-navy text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-playfair font-bold mb-6">
            Need Help with Your Booking?
          </h2>
          <p className="text-xl text-beige mb-8 max-w-2xl mx-auto">
            Our friendly team is here to assist you with any questions about availability, pricing,
            or special requirements.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <a
              href={`tel:${PROPERTY_CONFIG?.contact?.phone ?? ''}`}
              className="bg-coral hover:bg-coral/90 text-white px-10 py-4 text-lg rounded-2xl inline-flex items-center gap-2 transition-colors"
              aria-label="Call us now"
            >
              <Phone className="h-5 w-5" />
              Call Us Now
            </a>
            <a
              href={`mailto:${PROPERTY_CONFIG?.contact?.email ?? ''}`}
              className="border-2 border-beige text-beige hover:bg-beige hover:text-navy px-8 py-4 text-lg rounded-2xl inline-flex items-center gap-2 transition-colors"
              aria-label="Email support"
            >
              <Mail className="h-5 w-5" />
              Email Support
            </a>
          </div>
        </div>
      </section>
    </>
  );
}

