import { MetadataRoute } from 'next';
import { locales } from '@/lib/locales';

const baseUrl = process.env.NEXT_PUBLIC_PROPERTY_URL || 'https://example.com';

const routes = [
  '',
  '/the-property',
  '/location',
  '/book',
  '/contact',
  '/reviews',
  '/privacy-policy',
  '/terms',
];

export default function sitemap(): MetadataRoute.Sitemap {
  const sitemap: MetadataRoute.Sitemap = [];

  locales.forEach((locale) => {
    routes.forEach((route) => {
      sitemap.push({
        url: `${baseUrl}/${locale}${route}`,
        lastModified: new Date(),
        changeFrequency: route === '' ? 'daily' : route === '/book' ? 'hourly' : 'weekly',
        priority: route === '' ? 1.0 : route === '/book' ? 0.9 : 0.7,
      });
    });
  });

  return sitemap;
}
