import type { Metadata } from 'next';
import { Hero } from '@/components/ui/Hero';
import { ReviewForm } from '@/components/reviews/ReviewForm';
import { ReviewsSection } from '@/components/reviews/ReviewsSection';
import { GALLERY_IMAGES } from '@/data/seed';

export const metadata: Metadata = {
  title: 'Guest Reviews | See What Our Guests Say',
  description:
    'Read authentic reviews from guests who have stayed at Stay by the Sea. Discover why visitors love our luxury Blackpool accommodation.',
  alternates: {
    canonical: '/reviews',
  },
};

export default function ReviewsPage() {
  return (
    <>
      <Hero
        title="Guest Reviews"
        subtitle="Hear from guests who have experienced our hospitality"
        backgroundImage={GALLERY_IMAGES[0]?.src}
        showCTAs={false}
        height="medium"
      />

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-playfair font-bold text-navy mb-6">
              What Our Guests Are Saying
            </h2>
            <p className="text-lg text-navy/70 max-w-2xl mx-auto">
              Don&apos;t just take our word for it. Read real reviews from guests who have stayed with us.
            </p>
          </div>

          <ReviewsSection limit={100} showViewAll={false} />
        </div>
      </section>

      <section className="py-20 bg-beige/30">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-playfair font-bold text-navy mb-6">
              Share Your Experience
            </h2>
            <p className="text-lg text-navy/70">
              Stayed with us? We&apos;d love to hear about your experience!
            </p>
          </div>

          <ReviewForm />
        </div>
      </section>
    </>
  );
}
