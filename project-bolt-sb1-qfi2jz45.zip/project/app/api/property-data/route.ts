import { NextResponse } from 'next/server';
import { PROPERTY_CONFIG, AMENITIES, ATTRACTIONS } from '@/lib/constants';

export async function GET() {
  const propertyData = {
    name: 'Stay by the Sea - Blackpool',
    type: 'Holiday Rental',
    url: process.env.NEXT_PUBLIC_PROPERTY_URL || 'https://example.com',
    description: {
      short: 'Luxury holiday rental for up to 14 guests in Blackpool\'s South Shore',
      full: 'Luxury seaside accommodation for up to 14 guests in Blackpool. Features 7 double bedrooms, 2 modern bathrooms, air conditioning, underfloor heating, private parking for 2 cars, and all modern amenities. Located just 50 yards from the beach in South Shore, within walking distance of Pleasure Beach and all major attractions.',
    },
    capacity: {
      maxGuests: 14,
      bedrooms: 7,
      beds: 7,
      bathrooms: 2,
      bedType: 'double',
    },
    location: {
      address: {
        street: process.env.NEXT_PUBLIC_ADDRESS_LINE_1,
        city: process.env.NEXT_PUBLIC_ADDRESS_CITY || 'Blackpool',
        region: 'Lancashire',
        postcode: process.env.NEXT_PUBLIC_ADDRESS_POSTCODE,
        country: 'United Kingdom',
        countryCode: 'GB',
      },
      coordinates: {
        latitude: PROPERTY_CONFIG.coordinates.lat,
        longitude: PROPERTY_CONFIG.coordinates.lng,
      },
      distanceToBeach: '50 yards',
      distanceToBeachMeters: 45,
      nearbyAttractions: ATTRACTIONS.map((attraction) => ({
        name: attraction.name,
        distance: attraction.distance,
        walkingTime: attraction.walkTime,
        type: 'attraction',
      })),
    },
    amenities: AMENITIES.map((amenity) => ({
      id: amenity.id,
      name: amenity.label,
      icon: amenity.icon,
      category: 'comfort',
    })),
    features: {
      parking: {
        available: true,
        type: 'private',
        spaces: 2,
        cost: 'free',
      },
      heating: {
        airConditioning: true,
        underfloorHeating: true,
        centralHeating: true,
      },
      kitchen: {
        available: true,
        type: 'full',
        equipment: ['refrigerator', 'oven', 'microwave', 'dishwasher', 'kettle', 'toaster'],
      },
      internet: {
        wifi: true,
        speed: 'high-speed',
      },
      entertainment: {
        smartTVs: true,
        netflix: true,
        count: 7,
      },
    },
    policies: {
      checkIn: {
        from: '15:00',
        to: '18:00',
        type: 'self-checkin',
        method: 'door code',
      },
      checkOut: {
        time: '10:00',
      },
      cancellation: 'flexible',
      smoking: false,
      pets: false,
      parties: false,
      quietHours: {
        from: '22:00',
        to: '08:00',
      },
      children: true,
      infantsAllowed: true,
    },
    contact: {
      phone: PROPERTY_CONFIG.contact.phone,
      email: PROPERTY_CONFIG.contact.email,
      whatsapp: PROPERTY_CONFIG.contact.whatsapp,
      availableLanguages: ['en', 'es', 'fr', 'de'],
      responseTime: 'within 1 hour',
    },
    pricing: {
      currency: 'GBP',
      priceRange: {
        min: 300,
        max: 800,
        period: 'per night',
      },
      additionalFees: {
        cleaningFee: 'included',
        securityDeposit: 'may apply',
      },
    },
    booking: {
      instantConfirmation: true,
      minimumStay: {
        nights: 2,
        flexibleInOffSeason: true,
      },
      paymentMethods: ['credit_card', 'debit_card', 'paypal'],
      bookingPlatforms: ['direct', 'airbnb', 'booking.com'],
    },
    images: [
      {
        url: 'https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080',
        caption: 'Modern living room with coastal views',
        type: 'living_room',
      },
      {
        url: 'https://images.pexels.com/photos/271618/pexels-photo-271618.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080',
        caption: 'Spacious double bedroom',
        type: 'bedroom',
      },
      {
        url: 'https://images.pexels.com/photos/1454806/pexels-photo-1454806.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080',
        caption: 'Fully equipped modern kitchen',
        type: 'kitchen',
      },
    ],
    ratings: {
      overall: 4.9,
      cleanliness: 5.0,
      accuracy: 4.9,
      checkIn: 5.0,
      communication: 5.0,
      location: 5.0,
      value: 4.8,
      reviewCount: 50,
    },
    highlights: [
      '7 double beds for up to 14 guests',
      'Air conditioning and underfloor heating',
      'Private parking for 2 cars',
      'Just 50 yards from the beach',
      'Walking distance to Pleasure Beach',
      'Self check-in with door code',
      'Smart TVs in all bedrooms',
      'Modern fully equipped kitchen',
    ],
    suitableFor: [
      'Large families',
      'Group getaways',
      'Hen and stag parties (well-behaved)',
      'Multi-family holidays',
      'Extended family reunions',
      'Friends trips',
    ],
    accessibility: {
      wheelchairAccessible: false,
      stepFreeAccess: false,
      groundFloorBedroom: false,
    },
    lastUpdated: new Date().toISOString(),
    dataVersion: '1.0',
  };

  return NextResponse.json(propertyData, {
    headers: {
      'Content-Type': 'application/json',
      'Cache-Control': 'public, max-age=3600, s-maxage=3600',
      'Access-Control-Allow-Origin': '*',
    },
  });
}
