import { NextResponse } from 'next/server';
import { AMENITIES } from '@/lib/constants';

export async function GET() {
  const amenitiesData = {
    propertyName: 'Stay by the Sea - Blackpool',
    totalAmenities: AMENITIES.length,
    categories: {
      comfort: [
        { id: 'air-con', name: 'Air Conditioning', description: 'Stay cool in summer with air conditioning throughout the property', available: true },
        { id: 'heating', name: 'Underfloor Heating', description: 'Keep warm in winter with luxurious underfloor heating', available: true },
        { id: 'smart-tv', name: 'Smart TVs', description: '7 Smart TVs - one in each bedroom plus living room', available: true, count: 7 },
      ],
      kitchen: [
        { id: 'kitchen', name: 'Full Kitchen', description: 'Modern, fully equipped kitchen with all appliances', available: true },
        { id: 'refrigerator', name: 'Refrigerator', available: true },
        { id: 'oven', name: 'Oven & Hob', available: true },
        { id: 'microwave', name: 'Microwave', available: true },
        { id: 'dishwasher', name: 'Dishwasher', available: true },
        { id: 'kettle', name: 'Kettle', available: true },
        { id: 'toaster', name: 'Toaster', available: true },
        { id: 'cookware', name: 'Cookware & Utensils', available: true },
      ],
      connectivity: [
        { id: 'wifi', name: 'High-Speed WiFi', description: 'Fast and reliable WiFi throughout the property', available: true, speed: '100+ Mbps' },
      ],
      parking: [
        { id: 'parking', name: 'Private Parking', description: 'Two dedicated parking spaces directly outside', available: true, spaces: 2, cost: 'free' },
      ],
      bathroom: [
        { id: 'towels', name: 'Towels Provided', available: true },
        { id: 'toiletries', name: 'Basic Toiletries', available: true },
        { id: 'hairdryer', name: 'Hair Dryer', available: true },
        { id: 'shower', name: 'Walk-in Showers', available: true, count: 2 },
      ],
      bedroom: [
        { id: 'linens', name: 'Fresh Linens', description: 'High-quality bed linens provided', available: true },
        { id: 'double-beds', name: 'Double Beds', available: true, count: 7 },
        { id: 'wardrobe', name: 'Wardrobe Space', available: true },
      ],
      safety: [
        { id: 'smoke-alarm', name: 'Smoke Alarms', available: true },
        { id: 'carbon-monoxide', name: 'Carbon Monoxide Detector', available: true },
        { id: 'fire-extinguisher', name: 'Fire Extinguisher', available: true },
        { id: 'first-aid', name: 'First Aid Kit', available: true },
      ],
      entertainment: [
        { id: 'netflix', name: 'Netflix', available: true },
        { id: 'streaming', name: 'Streaming Services', available: true },
      ],
      outdoor: [
        { id: 'beach-access', name: 'Beach Access', description: 'Just 50 yards to the beach', available: true, distance: '50 yards' },
      ],
      laundry: [
        { id: 'washing-machine', name: 'Washing Machine', available: true },
        { id: 'iron', name: 'Iron & Ironing Board', available: true },
      ],
    },
    allAmenities: AMENITIES.map((amenity) => ({
      id: amenity.id,
      name: amenity.label,
      icon: amenity.icon,
    })),
    notAvailable: [
      'Pool',
      'Hot Tub',
      'Gym',
      'Elevator',
      'Wheelchair Access',
      'Pet Friendly',
    ],
    provided: {
      kitchen: ['Tea', 'Coffee', 'Sugar', 'Salt', 'Pepper', 'Cooking Oil'],
      bathroom: ['Shampoo', 'Conditioner', 'Body Wash', 'Hand Soap'],
      general: ['Cleaning Supplies', 'Waste Bags', 'Recycling Bins'],
    },
    lastUpdated: new Date().toISOString(),
  };

  return NextResponse.json(amenitiesData, {
    headers: {
      'Content-Type': 'application/json',
      'Cache-Control': 'public, max-age=86400, s-maxage=86400',
      'Access-Control-Allow-Origin': '*',
    },
  });
}
