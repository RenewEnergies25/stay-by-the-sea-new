import { NextResponse } from 'next/server';
import {
  getOrganizationSchema,
  getAccommodationSchema,
  getPlaceSchema,
  getHowToSchema,
  getProductSchema,
} from '@/lib/structured-data';

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const locale = searchParams.get('locale') || 'en';

  const schema = {
    '@context': 'https://schema.org',
    '@graph': [
      getOrganizationSchema(),
      getAccommodationSchema(locale),
      getPlaceSchema(),
      getHowToSchema(),
      getProductSchema(),
    ],
  };

  return NextResponse.json(schema, {
    headers: {
      'Content-Type': 'application/ld+json',
      'Cache-Control': 'public, max-age=3600, s-maxage=3600',
      'Access-Control-Allow-Origin': '*',
    },
  });
}
