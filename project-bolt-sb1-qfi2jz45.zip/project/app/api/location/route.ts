import { NextResponse } from 'next/server';
import { PROPERTY_CONFIG, ATTRACTIONS } from '@/lib/constants';

export async function GET() {
  const locationData = {
    property: {
      name: 'Stay by the Sea - Blackpool',
      coordinates: {
        latitude: PROPERTY_CONFIG.coordinates.lat,
        longitude: PROPERTY_CONFIG.coordinates.lng,
      },
      address: {
        street: process.env.NEXT_PUBLIC_ADDRESS_LINE_1,
        city: process.env.NEXT_PUBLIC_ADDRESS_CITY || 'Blackpool',
        region: 'Lancashire',
        postcode: process.env.NEXT_PUBLIC_ADDRESS_POSTCODE,
        country: 'United Kingdom',
        countryCode: 'GB',
      },
      area: 'South Shore',
      distanceToBeach: '50 yards (45 meters)',
    },
    nearbyAttractions: ATTRACTIONS.map((attraction) => ({
      name: attraction.name,
      type: 'attraction',
      distance: attraction.distance,
      walkingTime: attraction.walkTime,
      description: getAttractionDescription(attraction.name),
      coordinates: { lat: attraction.lat, lng: attraction.lng },
    })),
    transportation: {
      airport: {
        nearest: 'Manchester Airport',
        distance: '50 miles',
        driveTime: '1 hour',
      },
      trainStation: {
        nearest: 'Blackpool South',
        distance: '0.5 miles',
        walkTime: '10 minutes',
      },
      busStops: {
        nearest: 'Nearby on South Promenade',
        distance: '100 yards',
        walkTime: '2 minutes',
      },
      tramStops: {
        nearest: 'Pleasure Beach',
        distance: '0.3 miles',
        walkTime: '6 minutes',
      },
      parking: {
        onSite: true,
        spaces: 2,
        cost: 'free',
      },
    },
    amenities: {
      restaurants: {
        count: '20+',
        distance: 'within 0.5 miles',
        walkTime: 'within 10 minutes',
      },
      shops: {
        supermarket: {
          nearest: 'Tesco Express',
          distance: '0.3 miles',
          walkTime: '6 minutes',
        },
        shopping: {
          nearest: 'Hounds Hill Shopping Centre',
          distance: '2 miles',
          driveTime: '10 minutes',
        },
      },
      medical: {
        pharmacy: {
          distance: '0.5 miles',
          walkTime: '10 minutes',
        },
        hospital: {
          nearest: 'Blackpool Victoria Hospital',
          distance: '2.5 miles',
          driveTime: '10 minutes',
        },
      },
      entertainment: {
        cinemas: true,
        arcades: true,
        pubs: true,
        nightclubs: true,
      },
    },
    localArea: {
      description: 'South Shore is Blackpool\'s premier residential area, offering a perfect blend of seaside charm and modern amenities. Just steps from the famous Blackpool Beach and within walking distance of the iconic Pleasure Beach, you\'re perfectly positioned to enjoy everything Blackpool has to offer.',
      characteristics: [
        'Quiet residential area',
        'Direct beach access',
        'Family-friendly environment',
        'Close to all major attractions',
        'Excellent restaurant scene',
        'Safe and well-lit streets',
      ],
      bestFor: [
        'Beach lovers',
        'Families with children',
        'Groups seeking central location',
        'Visitors wanting easy attraction access',
        'Those who value peaceful setting',
      ],
    },
    weather: {
      climate: 'Maritime temperate',
      summerTemp: '18-22°C (64-72°F)',
      winterTemp: '5-8°C (41-46°F)',
      rainyMonths: ['October', 'November', 'December', 'January'],
      bestVisit: ['June', 'July', 'August', 'September'],
    },
    directions: {
      fromManchester: {
        car: 'M6 North to M55 West, follow signs to Blackpool, then South Shore',
        duration: '1 hour',
        distance: '50 miles',
      },
      fromLiverpool: {
        car: 'M58 to M6 North to M55 West',
        duration: '1 hour 10 minutes',
        distance: '55 miles',
      },
      fromLondon: {
        car: 'M1 North to M6 North to M55 West',
        duration: '4-5 hours',
        distance: '260 miles',
        train: 'Direct train from London Euston to Blackpool North (3 hours)',
      },
    },
    lastUpdated: new Date().toISOString(),
  };

  return NextResponse.json(locationData, {
    headers: {
      'Content-Type': 'application/json',
      'Cache-Control': 'public, max-age=86400, s-maxage=86400',
      'Access-Control-Allow-Origin': '*',
    },
  });
}

function getAttractionDescription(name: string): string {
  const descriptions: Record<string, string> = {
    'Blackpool Pleasure Beach': 'Iconic amusement park with thrilling rides and attractions',
    'Blackpool Tower': 'Famous landmark with viewing platform and ballroom',
    'Sandcastle Waterpark': 'Indoor waterpark with slides and pools',
    'South Pier': 'Traditional seaside pier with amusements',
    'Promenade': 'Scenic seafront walkway perfect for strolls',
    'Blackpool Beach': 'Sandy beach stretching for miles',
    'Coral Island': 'Indoor amusement arcade and entertainment center',
    'Blackpool Zoo': 'Family-friendly zoo with diverse animal species',
  };

  return descriptions[name] || 'Popular local attraction';
}
