import './globals.css';
import type { Metadata } from 'next';
import { Header } from '@/components/layout/Header';
import { Footer } from '@/components/layout/Footer';
import { StickyCTA } from '@/components/ui/StickyCTA';
import { CookieConsent } from '@/components/CookieConsent';

export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_PROPERTY_URL || 'https://example.com'),
  title: {
    template: '%s | Stay by the Sea – Blackpool',
    default: 'Stay by the Sea – Blackpool | Luxury Holiday Rental for 14 Guests',
  },
  description:
    'Luxury seaside accommodation for up to 14 guests in Blackpool. 7 double beds, air con, private parking, near Pleasure Beach.',
  keywords: [
    'Blackpool holiday rental',
    'seaside accommodation',
    'luxury apartment',
    'South Shore',
    'Pleasure Beach',
    'group accommodation',
  ],
  authors: [{ name: 'Stay by the Sea' }],
  creator: 'Stay by the Sea',
  publisher: 'Stay by the Sea',
  formatDetection: { email: false, address: false, telephone: false },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
  verification: { google: 'google-site-verification-code' },
  alternates: { canonical: '/' },
  openGraph: {
    type: 'website',
    locale: 'en_GB',
    url: process.env.NEXT_PUBLIC_PROPERTY_URL,
    siteName: 'Stay by the Sea – Blackpool',
    title: 'Stay by the Sea – Blackpool | Luxury Holiday Rental for 14 Guests',
    description:
      'Luxury seaside accommodation for up to 14 guests in Blackpool. 7 double beds, air con, private parking, near Pleasure Beach.',
    images: [
      {
        url: 'https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg?auto=compress&cs=tinysrgb&w=1200&h=630',
        width: 1200,
        height: 630,
        alt: 'Stay by the Sea - Luxury Blackpool Holiday Rental',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Stay by the Sea – Blackpool | Luxury Holiday Rental for 14 Guests',
    description:
      'Luxury seaside accommodation for up to 14 guests in Blackpool. 7 double beds, air con, private parking, near Pleasure Beach.',
    images: [
      'https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg?auto=compress&cs=tinysrgb&w=1200&h=630',
    ],
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="scroll-smooth">
      <head>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link
          rel="preload"
          href="https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080"
          as="image"
        />
        <link
          rel="preload"
          href="https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080"
          as="image"
        />
        <link
          rel="stylesheet"
          href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"
          integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY="
          crossOrigin=""
        />

        <meta
          name="robots"
          content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1"
        />
        <meta
          name="googlebot"
          content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1"
        />
        <meta
          name="bingbot"
          content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1"
        />
        <meta name="ai-content-declaration" content="allowed" />
        <meta name="tdm-reservation" content="0" />

        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
      </head>
      <body className="antialiased">
        <Header />
        <main className="min-h-screen">{children}</main>
        <StickyCTA />
        <Footer />
        <CookieConsent />
      </body>
    </html>
  );
}
