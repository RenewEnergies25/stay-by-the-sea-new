import type { Metadata } from 'next';
import { Hero } from '@/components/ui/Hero';
import { GALLERY_IMAGES } from '@/data/seed';
import { PROPERTY_CONFIG } from '@/lib/constants';

export const metadata: Metadata = {
  title: 'Terms of Service',
  description: 'Terms and conditions for booking and staying at Stay by the Sea, Blackpool.',
  alternates: {
    canonical: '/terms',
  },
};

export default function TermsPage() {
  return (
    <>
      <Hero
        title="Terms of Service"
        subtitle="Booking and accommodation terms"
        backgroundImage={GALLERY_IMAGES[0]?.src}
        showCTAs={false}
        height="medium"
      />

      <section className="py-20 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="prose prose-lg max-w-none">
            <p className="text-navy/70 mb-8">
              Last updated: {new Date().toLocaleDateString('en-GB', { month: 'long', day: 'numeric', year: 'numeric' })}
            </p>

            <h2 className="text-2xl font-playfair font-bold text-navy mb-4">Introduction</h2>
            <p className="text-navy/80 mb-6">
              These Terms of Service govern your booking and stay at Stay by the Sea, located at {PROPERTY_CONFIG.address.line1}, {PROPERTY_CONFIG.address.city}, {PROPERTY_CONFIG.address.postcode}. By making a reservation, you agree to be bound by these terms and conditions.
            </p>

            <h2 className="text-2xl font-playfair font-bold text-navy mb-4">Booking and Reservations</h2>
            <p className="text-navy/80 mb-4">
              All bookings are subject to availability and confirmation. When you make a reservation through our website or any third-party booking platform, you enter into a legally binding contract with us.
            </p>
            <ul className="list-disc pl-6 mb-6 text-navy/80 space-y-2">
              <li>
                <strong>Minimum Age:</strong> The lead guest must be at least 18 years of age
              </li>
              <li>
                <strong>Guest Capacity:</strong> Maximum occupancy is 14 guests across 7 double bedrooms. Additional guests beyond this limit are not permitted
              </li>
              <li>
                <strong>Booking Confirmation:</strong> Your booking is confirmed once you receive a confirmation email from us or our booking platform partner
              </li>
              <li>
                <strong>Accuracy of Information:</strong> You must provide accurate and complete information when making a booking
              </li>
            </ul>

            <h2 className="text-2xl font-playfair font-bold text-navy mb-4">Payment Terms</h2>
            <p className="text-navy/80 mb-4">Payment terms depend on your booking method:</p>
            <ul className="list-disc pl-6 mb-6 text-navy/80 space-y-2">
              <li>
                <strong>Direct Bookings:</strong> Full payment is typically required at the time of booking unless otherwise specified
              </li>
              <li>
                <strong>Third-Party Platforms:</strong> Payment terms will be governed by the respective platform's policies (Airbnb, Booking.com, etc.)
              </li>
              <li>
                <strong>Security Deposit:</strong> A refundable security deposit may be required and will be returned within 7 days after checkout, subject to property inspection
              </li>
              <li>
                <strong>Accepted Payment Methods:</strong> We accept major credit cards, debit cards, and bank transfers through our secure payment processors
              </li>
            </ul>

            <h2 className="text-2xl font-playfair font-bold text-navy mb-4">Cancellation Policy</h2>
            <p className="text-navy/80 mb-4">
              Our cancellation policy is designed to be fair to both guests and property owners:
            </p>
            <ul className="list-disc pl-6 mb-6 text-navy/80 space-y-2">
              <li>
                <strong>Standard Policy:</strong> Cancellations made more than 30 days before check-in receive a full refund
              </li>
              <li>
                <strong>14-30 Days Notice:</strong> Cancellations made 14-30 days before check-in receive a 50% refund
              </li>
              <li>
                <strong>Less than 14 Days:</strong> Cancellations made less than 14 days before check-in are non-refundable
              </li>
              <li>
                <strong>Third-Party Bookings:</strong> Cancellation policies of the booking platform apply (Airbnb, Booking.com, Smoobu)
              </li>
              <li>
                <strong>Force Majeure:</strong> Exceptional circumstances may be considered on a case-by-case basis
              </li>
            </ul>

            <h2 className="text-2xl font-playfair font-bold text-navy mb-4">Check-In and Check-Out</h2>
            <ul className="list-disc pl-6 mb-6 text-navy/80 space-y-2">
              <li>
                <strong>Check-In Time:</strong> Standard check-in is from 4:00 PM. Early check-in may be available upon request and subject to availability
              </li>
              <li>
                <strong>Check-Out Time:</strong> Check-out is by 11:00 AM. Late check-out may be arranged in advance for an additional fee
              </li>
              <li>
                <strong>Access Instructions:</strong> You will receive detailed check-in instructions and access codes via email 24 hours before arrival
              </li>
              <li>
                <strong>Key/Access Card:</strong> You are responsible for all keys or access cards provided during your stay
              </li>
            </ul>

            <h2 className="text-2xl font-playfair font-bold text-navy mb-4">Guest Responsibilities</h2>
            <p className="text-navy/80 mb-4">As a guest at Stay by the Sea, you agree to:</p>
            <ul className="list-disc pl-6 mb-6 text-navy/80 space-y-2">
              <li>Treat the property with respect and care as if it were your own home</li>
              <li>Report any damages, accidents, or maintenance issues immediately</li>
              <li>Not exceed the maximum guest capacity</li>
              <li>Comply with all house rules provided in the property information pack</li>
              <li>Not use the property for any illegal activities or unauthorized commercial purposes</li>
              <li>Respect neighbors and maintain reasonable noise levels, especially during evening hours (10 PM - 8 AM)</li>
              <li>Properly dispose of all rubbish and leave the property in a reasonably clean condition</li>
              <li>Not smoke anywhere on the property (the property is strictly non-smoking)</li>
            </ul>

            <h2 className="text-2xl font-playfair font-bold text-navy mb-4">Property Rules</h2>
            <p className="text-navy/80 mb-4">The following rules must be observed during your stay:</p>
            <ul className="list-disc pl-6 mb-6 text-navy/80 space-y-2">
              <li>
                <strong>No Parties or Events:</strong> The property is for quiet residential use only. Parties, events, or gatherings beyond the registered guests are strictly prohibited
              </li>
              <li>
                <strong>Pets:</strong> Pets are not permitted unless explicitly agreed in advance
              </li>
              <li>
                <strong>Parking:</strong> {PROPERTY_CONFIG.amenities.parkingSpaces} private parking spaces are provided. Please do not park in unauthorized areas
              </li>
              <li>
                <strong>Smoking:</strong> The property is strictly non-smoking. Smoking is not permitted anywhere on the property. A cleaning fee will be charged if evidence of smoking is found
              </li>
              <li>
                <strong>Safety:</strong> Do not tamper with smoke detectors, fire alarms, or safety equipment
              </li>
            </ul>

            <h2 className="text-2xl font-playfair font-bold text-navy mb-4">Liability and Insurance</h2>
            <p className="text-navy/80 mb-6">
              We maintain appropriate property insurance, however:
            </p>
            <ul className="list-disc pl-6 mb-6 text-navy/80 space-y-2">
              <li>We are not liable for any loss, damage, or theft of personal belongings during your stay</li>
              <li>Guests are responsible for any damage caused to the property, furnishings, or equipment beyond normal wear and tear</li>
              <li>We recommend all guests obtain comprehensive travel insurance covering personal property and liability</li>
              <li>We are not liable for any injury occurring on the premises unless caused by our negligence</li>
              <li>Guests are responsible for the conduct of all visitors and additional guests</li>
            </ul>

            <h2 className="text-2xl font-playfair font-bold text-navy mb-4">Maintenance and Access</h2>
            <p className="text-navy/80 mb-6">
              We reserve the right to access the property during your stay for essential maintenance, repairs, or emergency situations. We will provide reasonable notice except in cases of emergency. If significant maintenance issues affect your enjoyment of the property, we will work to resolve them promptly or offer appropriate compensation.
            </p>

            <h2 className="text-2xl font-playfair font-bold text-navy mb-4">Force Majeure</h2>
            <p className="text-navy/80 mb-6">
              We are not liable for any failure to perform our obligations due to circumstances beyond our reasonable control, including but not limited to natural disasters, government restrictions, pandemics, severe weather, utility failures, or other force majeure events. In such cases, we will work with you to reschedule your booking or provide an appropriate refund based on the circumstances.
            </p>

            <h2 className="text-2xl font-playfair font-bold text-navy mb-4">Privacy and Data Protection</h2>
            <p className="text-navy/80 mb-6">
              We collect and process personal data in accordance with GDPR and UK data protection laws. Please refer to our <a href="/privacy-policy" className="text-coral hover:underline focus-ring rounded">Privacy Policy</a> for detailed information on how we handle your personal information.
            </p>

            <h2 className="text-2xl font-playfair font-bold text-navy mb-4">Modifications to Terms</h2>
            <p className="text-navy/80 mb-6">
              We reserve the right to modify these terms at any time. Changes will be posted on this page with an updated revision date. Your continued booking or use of the property after changes are posted constitutes acceptance of the modified terms. Terms in effect at the time of your booking will govern that specific reservation.
            </p>

            <h2 className="text-2xl font-playfair font-bold text-navy mb-4">Dispute Resolution</h2>
            <p className="text-navy/80 mb-6">
              If any dispute arises relating to your booking or stay, we encourage you to contact us directly first to resolve the matter amicably. If a resolution cannot be reached, both parties agree to attempt mediation before pursuing legal action.
            </p>

            <h2 className="text-2xl font-playfair font-bold text-navy mb-4">Governing Law</h2>
            <p className="text-navy/80 mb-6">
              These Terms of Service are governed by the laws of England and Wales. Any disputes arising from these terms or your stay will be subject to the exclusive jurisdiction of the courts of England and Wales.
            </p>

            <h2 className="text-2xl font-playfair font-bold text-navy mb-4">Severability</h2>
            <p className="text-navy/80 mb-6">
              If any provision of these terms is found to be unenforceable or invalid, that provision will be limited or eliminated to the minimum extent necessary, and the remaining provisions will remain in full force and effect.
            </p>

            <h2 className="text-2xl font-playfair font-bold text-navy mb-4">Contact Us</h2>
            <p className="text-navy/80 mb-4">
              If you have any questions about these Terms of Service, please contact us:
            </p>
            <p className="text-navy/80 mb-6">
              Email: <a href={`mailto:${PROPERTY_CONFIG.contact.email}`} className="text-coral hover:underline focus-ring rounded">{PROPERTY_CONFIG.contact.email}</a><br />
              Phone: <a href={`tel:${PROPERTY_CONFIG.contact.phone}`} className="text-coral hover:underline focus-ring rounded">{PROPERTY_CONFIG.contact.phone}</a><br />
              WhatsApp: <a href={PROPERTY_CONFIG.contact.whatsapp} target="_blank" rel="noopener noreferrer" className="text-coral hover:underline focus-ring rounded">Message us on WhatsApp</a>
            </p>

            <p className="text-navy/80 mb-6">
              Address:<br />
              {PROPERTY_CONFIG.address.line1}<br />
              {PROPERTY_CONFIG.address.line2}<br />
              {PROPERTY_CONFIG.address.city} {PROPERTY_CONFIG.address.postcode}
            </p>

            <h2 className="text-2xl font-playfair font-bold text-navy mb-4">Acknowledgment</h2>
            <p className="text-navy/80">
              By completing a booking, you acknowledge that you have read, understood, and agree to be bound by these Terms of Service, along with our Privacy Policy and any additional house rules provided at check-in.
            </p>
          </div>
        </div>
      </section>
    </>
  );
}
