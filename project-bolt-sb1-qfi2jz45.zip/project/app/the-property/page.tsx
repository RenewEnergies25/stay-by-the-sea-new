import type { Metadata } from 'next';
import { Hero } from '@/components/ui/Hero';
import { Gallery } from '@/components/ui/Gallery';
import { AmenityPill } from '@/components/ui/AmenityPill';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { SEED_CONTENT, GALLERY_IMAGES } from '@/data/seed';
import { AMENITIES } from '@/lib/constants';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Calendar, Users, Bed, Bath, Car, Thermometer } from 'lucide-react';

export const metadata: Metadata = {
  title: '7 double beds, AC & parking | The Property',
  description: 'Explore our luxury Blackpool holiday rental. 7 double beds, 2 bathrooms, air conditioning, underfloor heating, private parking. Modern coastal comfort.',
  alternates: {
    canonical: '/the-property',
  },
};

export default function ThePropertyPage() {
  return (
    <>
      {/* Hero Section */}
      <Hero
        title="Modern Coastal Comfort"
        subtitle="Luxury accommodation designed for memorable stays"
        backgroundImage={GALLERY_IMAGES[4].src}
        showCTAs={false}
        height="medium"
      />

      {/* Quick Facts & Sticky CTA */}
      <div className="sticky top-16 z-40 bg-white/95 backdrop-blur-sm border-b border-beige/50 py-4">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="flex flex-wrap items-center gap-6">
              <div className="flex items-center space-x-2 text-navy">
                <Users className="h-5 w-5 text-teal" />
                <span className="font-medium">Sleeps 14</span>
              </div>
              <div className="flex items-center space-x-2 text-navy">
                <Bed className="h-5 w-5 text-teal" />
                <span className="font-medium">7 Double Beds</span>
              </div>
              <div className="flex items-center space-x-2 text-navy">
                <Bath className="h-5 w-5 text-teal" />
                <span className="font-medium">2 Bathrooms</span>
              </div>
              <div className="flex items-center space-x-2 text-navy">
                <Car className="h-5 w-5 text-teal" />
                <span className="font-medium">Private Parking</span>
              </div>
            </div>
            <Link href="/book">
              <Button className="btn-primary">
                <Calendar className="h-4 w-4 mr-2" />
                Book Now
              </Button>
            </Link>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <Tabs defaultValue="photos" className="space-y-12">
            <div className="border-b border-beige/30">
              <TabsList className="grid w-full grid-cols-4 bg-transparent h-auto p-0">
                <TabsTrigger 
                  value="photos" 
                  className="data-[state=active]:bg-transparent data-[state=active]:border-b-2 data-[state=active]:border-teal data-[state=active]:text-teal rounded-none py-4"
                >
                  Photos
                </TabsTrigger>
                <TabsTrigger 
                  value="amenities"
                  className="data-[state=active]:bg-transparent data-[state=active]:border-b-2 data-[state=active]:border-teal data-[state=active]:text-teal rounded-none py-4"
                >
                  Amenities
                </TabsTrigger>
                <TabsTrigger 
                  value="floorplan"
                  className="data-[state=active]:bg-transparent data-[state=active]:border-b-2 data-[state=active]:border-teal data-[state=active]:text-teal rounded-none py-4"
                >
                  Floorplan
                </TabsTrigger>
                <TabsTrigger 
                  value="rules"
                  className="data-[state=active]:bg-transparent data-[state=active]:border-b-2 data-[state=active]:border-teal data-[state=active]:text-teal rounded-none py-4"
                >
                  House Rules
                </TabsTrigger>
              </TabsList>
            </div>

            <TabsContent value="photos" className="space-y-12">
              <div>
                <h2 className="text-2xl md:text-3xl font-playfair font-bold text-navy mb-6">
                  Photo Gallery
                </h2>
                <Gallery images={GALLERY_IMAGES} />
              </div>
            </TabsContent>

            <TabsContent value="amenities" className="space-y-12">
              <div>
                <h2 className="text-2xl md:text-3xl font-playfair font-bold text-navy mb-6">
                  Property Amenities
                </h2>
                <p className="text-lg text-navy/70 mb-8 max-w-3xl">
                  Every comfort has been thoughtfully provided to ensure your stay is exceptional.
                </p>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {AMENITIES.map((amenity) => (
                    <AmenityPill
                      key={amenity.id}
                      icon={amenity.icon}
                      label={amenity.label}
                    />
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <Card className="border-0 shadow-lg">
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-3">
                      <Thermometer className="h-6 w-6 text-teal" />
                      <span>Climate Control</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-navy/70">
                      Stay comfortable year-round with both air conditioning for warm summer days and 
                      underfloor heating for cosy winter evenings.
                    </p>
                  </CardContent>
                </Card>

                <Card className="border-0 shadow-lg">
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-3">
                      <Car className="h-6 w-6 text-teal" />
                      <span>Private Parking</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-navy/70">
                      Two dedicated parking spaces directly outside the property. No need to worry 
                      about finding parking in busy Blackpool.
                    </p>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="floorplan" className="space-y-8">
              <div className="text-center py-16">
                <h2 className="text-2xl md:text-3xl font-playfair font-bold text-navy mb-6">
                  Floorplan
                </h2>
                <p className="text-lg text-navy/70 mb-8">
                  Detailed floorplan coming soon. Contact us for layout information.
                </p>
                <Link href="/contact">
                  <Button className="btn-secondary">
                    Request Floorplan
                  </Button>
                </Link>
              </div>
            </TabsContent>

            <TabsContent value="rules" className="space-y-8">
              <div>
                <h2 className="text-2xl md:text-3xl font-playfair font-bold text-navy mb-6">
                  House Rules
                </h2>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <Card className="border-0 shadow-lg">
                    <CardHeader>
                      <CardTitle className="text-teal">Check-in & Check-out</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <p><strong>Check-in:</strong> 4:00 PM onwards</p>
                      <p><strong>Check-out:</strong> 11:00 AM</p>
                      <p><strong>Self check-in:</strong> Door code provided</p>
                    </CardContent>
                  </Card>

                  <Card className="border-0 shadow-lg">
                    <CardHeader>
                      <CardTitle className="text-teal">Property Guidelines</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <p>• Maximum 14 guests</p>
                      <p>• No smoking anywhere on the property</p>
                      <p>• No pets allowed</p>
                      <p>• Quiet hours: 10 PM - 8 AM</p>
                    </CardContent>
                  </Card>

                  <Card className="border-0 shadow-lg">
                    <CardHeader>
                      <CardTitle className="text-teal">What's Provided</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <p>• Fresh linens and towels</p>
                      <p>• Basic toiletries</p>
                      <p>• Tea, coffee, and kitchen basics</p>
                      <p>• Cleaning supplies</p>
                    </CardContent>
                  </Card>

                  <Card className="border-0 shadow-lg">
                    <CardHeader>
                      <CardTitle className="text-teal">Respect & Care</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <p>• Treat the space as your own home</p>
                      <p>• Report any issues immediately</p>
                      <p>• Keep noise to a minimum</p>
                      <p>• Leave the property tidy upon departure</p>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-beige/30">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-playfair font-bold text-navy mb-6">
            Ready to Experience Luxury?
          </h2>
          <p className="text-lg text-navy/70 mb-8 max-w-2xl mx-auto">
            Book your stay at Stay by the Sea and enjoy modern comfort in Blackpool's premier location.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link href="/book">
              <Button className="btn-primary text-lg px-10 py-4">
                <Calendar className="h-5 w-5 mr-2" />
                Check Availability
              </Button>
            </Link>
            <Link href="/location">
              <Button variant="outline" className="btn-secondary px-8 py-4 text-lg">
                Explore Location
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}