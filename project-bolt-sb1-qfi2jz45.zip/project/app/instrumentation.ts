// app/instrumentation.ts
export async function register() {
  // Instrumentation disabled for deployment stability
  console.log('[Instrumentation] Instrumentation disabled');
}