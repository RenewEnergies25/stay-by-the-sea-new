import type { Metadata } from 'next';
import { Hero } from '@/components/ui/Hero';
import { GALLERY_IMAGES } from '@/data/seed';
import { PROPERTY_CONFIG } from '@/lib/constants';

export const metadata: Metadata = {
  title: 'Privacy Policy',
  description: 'Learn how we collect, use, and protect your personal information at Stay by the Sea.',
  alternates: {
    canonical: '/privacy-policy',
  },
};

export default function PrivacyPolicyPage() {
  return (
    <>
      <Hero
        title="Privacy Policy"
        subtitle="How we handle your personal information"
        backgroundImage={GALLERY_IMAGES[0]?.src}
        showCTAs={false}
        height="medium"
      />

      <section className="py-20 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="prose prose-lg max-w-none">
            <p className="text-navy/70 mb-8">
              Last updated: {new Date().toLocaleDateString('en-GB', { month: 'long', day: 'numeric', year: 'numeric' })}
            </p>

            <h2 className="text-2xl font-playfair font-bold text-navy mb-4">Introduction</h2>
            <p className="text-navy/80 mb-6">
              At Stay by the Sea, we respect your privacy and are committed to protecting your personal data.
              This privacy policy explains how we collect, use, and safeguard your information when you visit
              our website or book accommodation with us.
            </p>

            <h2 className="text-2xl font-playfair font-bold text-navy mb-4">Information We Collect</h2>
            <p className="text-navy/80 mb-4">We collect the following types of information:</p>
            <ul className="list-disc pl-6 mb-6 text-navy/80 space-y-2">
              <li>
                <strong>Booking Information:</strong> Name, email address, phone number, and payment details
                when you make a reservation
              </li>
              <li>
                <strong>Website Analytics:</strong> Pages visited, time on site, device type, browser information,
                and interaction data to improve our services
              </li>
              <li>
                <strong>Review Data:</strong> Name, email (optional), and review content when you submit a guest review
              </li>
              <li>
                <strong>Cookies:</strong> Small data files stored on your device to enhance your browsing experience
              </li>
            </ul>

            <h2 className="text-2xl font-playfair font-bold text-navy mb-4">How We Use Your Information</h2>
            <p className="text-navy/80 mb-4">We use your information to:</p>
            <ul className="list-disc pl-6 mb-6 text-navy/80 space-y-2">
              <li>Process and manage your bookings</li>
              <li>Communicate with you about your reservation</li>
              <li>Improve our website and services based on usage patterns</li>
              <li>Display guest reviews to help future visitors</li>
              <li>Send booking confirmations and important updates</li>
              <li>Comply with legal obligations</li>
            </ul>

            <h2 className="text-2xl font-playfair font-bold text-navy mb-4">Analytics and Tracking</h2>
            <p className="text-navy/80 mb-6">
              We use analytics tools to track visitor behavior, page views, and booking interactions. This helps
              us understand how guests use our website and improve their experience. We track:
            </p>
            <ul className="list-disc pl-6 mb-6 text-navy/80 space-y-2">
              <li>Page views and navigation paths</li>
              <li>Time spent on pages</li>
              <li>Booking platform clicks and preferences</li>
              <li>Device and browser information</li>
              <li>Scroll depth and engagement metrics</li>
            </ul>

            <h2 className="text-2xl font-playfair font-bold text-navy mb-4">Cookies</h2>
            <p className="text-navy/80 mb-6">
              We use cookies to enhance your browsing experience and collect analytics data. You can control
              cookie preferences through your browser settings or by declining our cookie consent banner.
              Note that disabling cookies may limit some website functionality.
            </p>

            <h2 className="text-2xl font-playfair font-bold text-navy mb-4">Data Security</h2>
            <p className="text-navy/80 mb-6">
              We implement appropriate security measures to protect your personal information from unauthorized
              access, alteration, disclosure, or destruction. Payment information is processed securely through
              trusted payment providers and is not stored on our servers.
            </p>

            <h2 className="text-2xl font-playfair font-bold text-navy mb-4">Third-Party Services</h2>
            <p className="text-navy/80 mb-4">
              We may share your information with trusted third-party services including:
            </p>
            <ul className="list-disc pl-6 mb-6 text-navy/80 space-y-2">
              <li>Booking platforms (Smoobu, Airbnb, Booking.com)</li>
              <li>Payment processors (Stripe, PayPal)</li>
              <li>Email service providers</li>
              <li>Analytics services (Supabase)</li>
            </ul>
            <p className="text-navy/80 mb-6">
              These third parties are contractually obligated to protect your data and only use it for the
              purposes we specify.
            </p>

            <h2 className="text-2xl font-playfair font-bold text-navy mb-4">Your Rights</h2>
            <p className="text-navy/80 mb-4">Under GDPR and UK data protection laws, you have the right to:</p>
            <ul className="list-disc pl-6 mb-6 text-navy/80 space-y-2">
              <li>Access your personal data</li>
              <li>Correct inaccurate data</li>
              <li>Request deletion of your data</li>
              <li>Object to data processing</li>
              <li>Request data portability</li>
              <li>Withdraw consent at any time</li>
            </ul>

            <h2 className="text-2xl font-playfair font-bold text-navy mb-4">Data Retention</h2>
            <p className="text-navy/80 mb-6">
              We retain your personal data only for as long as necessary to fulfill the purposes outlined in
              this policy, comply with legal obligations, and resolve disputes. Booking information is typically
              retained for 7 years for tax purposes. Analytics data is retained for 2 years.
            </p>

            <h2 className="text-2xl font-playfair font-bold text-navy mb-4">Contact Us</h2>
            <p className="text-navy/80 mb-6">
              If you have any questions about this privacy policy or wish to exercise your data rights,
              please contact us at:
            </p>
            <p className="text-navy/80 mb-6">
              Email: {PROPERTY_CONFIG.contact.email}<br />
              Phone: {PROPERTY_CONFIG.contact.phone}
            </p>

            <h2 className="text-2xl font-playfair font-bold text-navy mb-4">Changes to This Policy</h2>
            <p className="text-navy/80">
              We may update this privacy policy from time to time. Any changes will be posted on this page
              with an updated revision date. We encourage you to review this policy periodically.
            </p>
          </div>
        </div>
      </section>
    </>
  );
}
