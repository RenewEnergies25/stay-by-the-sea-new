import type { Metadata } from 'next';
import { Hero } from '@/components/ui/Hero';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ATTRACTIONS, PROPERTY_CONFIG } from '@/lib/constants';
import { GALLERY_IMAGES } from '@/data/seed';
import Link from 'next/link';
import dynamic from 'next/dynamic';
import { MapPin, Clock, Car, Brain as Train, Plane, Calendar } from 'lucide-react';

const InteractiveMap = dynamic(
  () => import('@/components/ui/InteractiveMap'),
  {
    ssr: false,
    loading: () => <div className="mx-auto max-w-4xl aspect-square rounded-2xl overflow-hidden shadow-2xl bg-gray-100 animate-pulse" />
  }
);

export const metadata: Metadata = {
  title: 'Prime South Shore Location | Near Pleasure Beach & Attractions',
  description: 'Perfectly located in Blackpool\'s South Shore. Walking distance to Pleasure Beach, South Pier, Blackpool Tower. Easy transport links and attractions nearby.',
  alternates: {
    canonical: '/location',
  },
};

export default function LocationPage() {
  return (
    <>
      {/* Hero Section */}
      <Hero
        title="Prime South Shore Location"
        subtitle="Walking distance to Blackpool's top attractions"
        backgroundImage="https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080"
        showCTAs={false}
        height="medium"
      />

      {/* Address & Quick Info */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <div className="inline-flex items-center space-x-2 bg-teal/10 px-6 py-3 rounded-full mb-6">
              <MapPin className="h-5 w-5 text-teal" />
              <span className="font-medium text-teal">
                {PROPERTY_CONFIG.address.line1}, {PROPERTY_CONFIG.address.city} {PROPERTY_CONFIG.address.postcode}
              </span>
            </div>
            <h2 className="text-3xl md:text-4xl font-playfair font-bold text-navy mb-6">
              Everything Within Walking Distance
            </h2>
            <p className="text-lg text-navy/70 max-w-3xl mx-auto">
              Stay by the Sea is perfectly positioned at 373 Promenade 1b and 1c Alexandra Road in Blackpool&apos;s desirable South Shore area,
              putting you at the heart of the action while maintaining a peaceful residential setting.
            </p>
          </div>
        </div>
      </section>

      {/* Nearby Attractions */}
      <section className="py-20 bg-beige/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-playfair font-bold text-navy mb-6">
              Top Attractions Nearby
            </h2>
            <p className="text-lg text-navy/70 max-w-2xl mx-auto">
              Discover Blackpool&apos;s famous attractions, all within easy walking distance of your accommodation.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {ATTRACTIONS.map((attraction, index) => (
              <Card key={index} className="border-0 shadow-lg hover:shadow-xl transition-shadow">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle className="text-xl font-playfair text-navy mb-2">
                        {attraction.name}
                      </CardTitle>
                      <div className="flex items-center space-x-4 text-sm text-teal">
                        <div className="flex items-center space-x-1">
                          <MapPin className="h-4 w-4" />
                          <span>{attraction.distance}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Clock className="h-4 w-4" />
                          <span>{attraction.walkTime}</span>
                        </div>
                      </div>
                    </div>
                    <span className="bg-teal/10 text-teal px-3 py-1 rounded-full text-xs font-medium">
                      {attraction.category}
                    </span>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-navy/70">{attraction.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Transport Links */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-playfair font-bold text-navy mb-6">
              Easy Transport Links
            </h2>
            <p className="text-lg text-navy/70 max-w-2xl mx-auto">
              Getting to and around Blackpool is simple with excellent transport connections.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="text-center border-0 shadow-lg">
              <CardContent className="pt-8">
                <div className="w-16 h-16 bg-teal/10 rounded-2xl mx-auto flex items-center justify-center mb-6">
                  <Train className="h-8 w-8 text-teal" />
                </div>
                <h3 className="text-xl font-playfair font-semibold text-navy mb-4">Tram Network</h3>
                <p className="text-navy/70 mb-4">
                  Tram stop just 3 minutes walk away. Direct access to Blackpool&apos;s heritage tram network 
                  connecting all major attractions.
                </p>
                <div className="text-sm text-teal font-medium">3 min walk</div>
              </CardContent>
            </Card>

            <Card className="text-center border-0 shadow-lg">
              <CardContent className="pt-8">
                <div className="w-16 h-16 bg-coral/10 rounded-2xl mx-auto flex items-center justify-center mb-6">
                  <Car className="h-8 w-8 text-coral" />
                </div>
                <h3 className="text-xl font-playfair font-semibold text-navy mb-4">By Car</h3>
                <p className="text-navy/70 mb-4">
                  Easy access from M55 motorway. Two dedicated parking spaces provided. 
                  Additional public parking available nearby.
                </p>
                <div className="text-sm text-coral font-medium">Private parking included</div>
              </CardContent>
            </Card>

            <Card className="text-center border-0 shadow-lg">
              <CardContent className="pt-8">
                <div className="w-16 h-16 bg-navy/10 rounded-2xl mx-auto flex items-center justify-center mb-6">
                  <Plane className="h-8 w-8 text-navy" />
                </div>
                <h3 className="text-xl font-playfair font-semibold text-navy mb-4">Airport Access</h3>
                <p className="text-navy/70 mb-4">
                  Manchester Airport 1 hour drive. Blackpool Airport 15 minutes. 
                  Liverpool Airport 1.5 hours via M58.
                </p>
                <div className="text-sm text-navy font-medium">Multiple airports nearby</div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Interactive Map Placeholder */}
      <section className="py-20 bg-beige/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-playfair font-bold text-navy mb-6">
              Explore the Area
            </h2>
            <p className="text-lg text-navy/70 max-w-2xl mx-auto">
              Explore our location with this interactive map showing the property and nearby attractions.
            </p>
          </div>

          <InteractiveMap 
            position={[PROPERTY_CONFIG.coordinates.lat, PROPERTY_CONFIG.coordinates.lng]}
            zoom={15}
            attractions={ATTRACTIONS}
            className="mx-auto max-w-4xl"
          />
          
          <div className="text-center mt-8">
            <p className="text-navy/70 mb-4">
              Click the marker to see more details about our location.
            </p>
            <Link href="/contact">
              <Button className="btn-secondary">
                Get Detailed Directions
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-navy text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-playfair font-bold mb-6">
            Perfect Location, Perfect Stay
          </h2>
          <p className="text-xl text-beige mb-8 max-w-2xl mx-auto">
            Experience the best of Blackpool from our prime South Shore location. 
            Everything you need is just a short walk away.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link href="/book">
              <Button className="bg-coral hover:bg-coral/90 text-white px-10 py-4 text-lg rounded-2xl">
                <Calendar className="h-5 w-5 mr-2" />
                Book Your Stay
              </Button>
            </Link>
            <Link href="/the-property">
              <Button variant="outline" className="border-beige text-beige hover:bg-beige hover:text-navy px-8 py-4 text-lg rounded-2xl">
                View Property
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}