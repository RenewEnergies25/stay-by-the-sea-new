import type { Metadata } from 'next';
import { Hero } from '@/components/ui/Hero';
import { Gallery } from '@/components/ui/Gallery';
import { AmenityPill } from '@/components/ui/AmenityPill';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { SEED_CONTENT, GALLERY_IMAGES, FAQ_DATA } from '@/data/seed';
import { AMENITIES, ATTRACTIONS } from '@/lib/constants';
import { PROPERTY_CONFIG } from '@/lib/constants';
import Link from 'next/link';
import dynamic from 'next/dynamic';
import { Users, MapPin, Car, Star, SquarePen as PenSquare } from 'lucide-react';
import {
  getOrganizationSchema,
  getAccommodationSchema,
  getPlaceSchema,
  getFAQSchema,
  getHowToSchema,
  getVideoSchema,
  getBreadcrumbSchema,
  getProductSchema
} from '@/lib/structured-data';

const InteractiveMap = dynamic(
  () => import('@/components/ui/InteractiveMap'),
  {
    ssr: false,
    loading: () => <div className="aspect-square rounded-2xl overflow-hidden shadow-2xl bg-gray-100 animate-pulse" />
  }
);

const baseUrl = process.env.NEXT_PUBLIC_PROPERTY_URL || 'https://example.com';

export const metadata: Metadata = {
  title: 'Seaside luxury for up to 14 guests in Blackpool',
  description: 'Luxury holiday rental in Blackpool\'s South Shore. 7 double beds, air con, underfloor heating, private parking. Near Pleasure Beach & attractions.',
  alternates: {
    canonical: '/',
  },
  openGraph: {
    images: [`${baseUrl}/api/og?title=Stay+by+the+Sea&subtitle=Luxury+Holiday+Rental+for+14+Guests`],
  },
};

const jsonLd = {
  '@context': 'https://schema.org',
  '@graph': [
    getOrganizationSchema(),
    getAccommodationSchema('en'),
    getPlaceSchema(),
    getProductSchema(),
    getFAQSchema(FAQ_DATA),
    getHowToSchema(),
    getVideoSchema(
      'https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg',
      'Stay by the Sea Property Tour',
      'Virtual tour of our luxury 7-bedroom holiday rental in Blackpool'
    ),
    getBreadcrumbSchema([
      { name: 'Home', url: '/' }
    ]),
  ],
};

export default function HomePage() {
  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />

      {/* Hero Section */}
      <Hero
        title={SEED_CONTENT.hero.title}
        subtitle={SEED_CONTENT.hero.subtitle}
        description={SEED_CONTENT.hero.description}
        backgroundImage={GALLERY_IMAGES[0].src}
        showCTAs={true}
        height="full"
        showDiscountBadge={true}
      />

      {/* Highlights Section */}
      <section className="py-20 bg-off-white" aria-labelledby="highlights-heading">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <header className="text-center mb-16">
            <h2 id="highlights-heading" className="text-3xl md:text-4xl font-playfair font-bold text-navy mb-6">
              Why Choose Stay by the Sea?
            </h2>
            <p className="text-lg text-navy/70 max-w-3xl mx-auto">
              Experience the perfect blend of luxury and location in Blackpool&apos;s most desirable area.
            </p>
          </header>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <Card className="text-center p-8 border-0 shadow-lg hover:shadow-xl transition-shadow">
              <CardContent className="space-y-4">
                <div className="w-16 h-16 bg-teal/10 rounded-2xl mx-auto flex items-center justify-center">
                  <Users className="h-8 w-8 text-teal" />
                </div>
                <h3 className="text-xl font-playfair font-semibold text-navy">Sleeps 14</h3>
                <p className="text-navy/70">Seven comfortable double beds perfect for large groups and families</p>
              </CardContent>
            </Card>

            <Card className="text-center p-8 border-0 shadow-lg hover:shadow-xl transition-shadow">
              <CardContent className="space-y-4">
                <div className="w-16 h-16 bg-coral/10 rounded-2xl mx-auto flex items-center justify-center">
                  <Star className="h-8 w-8 text-coral" />
                </div>
                <h3 className="text-xl font-playfair font-semibold text-navy">Premium Comforts</h3>
                <p className="text-navy/70">Air con, underfloor heating, smart TVs, and modern amenities</p>
              </CardContent>
            </Card>

            <Card className="text-center p-8 border-0 shadow-lg hover:shadow-xl transition-shadow">
              <CardContent className="space-y-4">
                <div className="w-16 h-16 bg-navy/10 rounded-2xl mx-auto flex items-center justify-center">
                  <MapPin className="h-8 w-8 text-navy" />
                </div>
                <h3 className="text-xl font-playfair font-semibold text-navy">Prime South Shore</h3>
                <p className="text-navy/70">Walking distance to Pleasure Beach, piers, and all major attractions</p>
              </CardContent>
            </Card>

            <Card className="text-center p-8 border-0 shadow-lg hover:shadow-xl transition-shadow">
              <CardContent className="space-y-4">
                <div className="w-16 h-16 bg-beige/50 rounded-2xl mx-auto flex items-center justify-center">
                  <Car className="h-8 w-8 text-navy" />
                </div>
                <h3 className="text-xl font-playfair font-semibold text-navy">Stress-Free Parking</h3>
                <p className="text-navy/70">Two dedicated parking spaces right outside the property</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Gallery Preview */}
      <section className="py-20 bg-white" aria-labelledby="gallery-heading">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <header className="text-center mb-16">
            <h2 id="gallery-heading" className="text-3xl md:text-4xl font-playfair font-bold text-navy mb-6">
              Take a Look Inside
            </h2>
            <p className="text-lg text-navy/70 max-w-2xl mx-auto">
              Discover our beautifully designed spaces that combine coastal charm with modern luxury.
            </p>
          </header>

          <Gallery images={GALLERY_IMAGES.slice(0, 6)} className="mb-12" />
          
          <div className="text-center">
            <Link href="/the-property">
              <Button variant="outline" className="btn-secondary">
                View All Photos
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Amenities Preview */}
      <section className="py-20 bg-beige/30" aria-labelledby="amenities-heading">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <header className="text-center mb-16">
            <h2 id="amenities-heading" className="text-3xl md:text-4xl font-playfair font-bold text-navy mb-6">
              Modern Amenities
            </h2>
            <p className="text-lg text-navy/70 max-w-2xl mx-auto">
              Everything you need for a comfortable and memorable stay by the sea.
            </p>
          </header>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 mb-12">
            {AMENITIES.slice(0, 8).map((amenity) => (
              <AmenityPill
                key={amenity.id}
                icon={amenity.icon}
                label={amenity.label}
              />
            ))}
          </div>

          <div className="text-center">
            <Link href="/the-property">
              <Button variant="outline" className="btn-secondary">
                View All Amenities
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Location Preview */}
      <section className="py-20 bg-white" aria-labelledby="location-heading">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <article>
              <h2 id="location-heading" className="text-3xl md:text-4xl font-playfair font-bold text-navy mb-6">
                Perfect Location
              </h2>
              <p className="text-lg text-navy/70 mb-8">
                Located in the heart of Blackpool&apos;s South Shore, you&apos;re perfectly positioned to explore all the resort has to offer.
              </p>

              <div className="space-y-4 mb-8">
                {ATTRACTIONS.slice(0, 5).map((attraction, index) => (
                  <div key={index} className="flex items-center space-x-4 p-4 bg-teal/5 rounded-xl">
                    <div className="w-3 h-3 bg-teal rounded-full flex-shrink-0" />
                    <div className="flex-grow">
                      <h4 className="font-semibold text-navy">{attraction.name}</h4>
                      <p className="text-sm text-navy/60">{attraction.distance} • {attraction.walkTime}</p>
                    </div>
                  </div>
                ))}
              </div>

              <Link href="/location">
                <Button className="btn-secondary">
                  <MapPin className="h-4 w-4 mr-2" />
                  Explore Location
                </Button>
              </Link>
            </article>

            <aside className="relative aspect-square" aria-label="Interactive map showing property location and nearby attractions">
              <InteractiveMap
                position={[PROPERTY_CONFIG.coordinates.lat, PROPERTY_CONFIG.coordinates.lng]}
                zoom={14}
                attractions={ATTRACTIONS}
                className="aspect-square rounded-2xl overflow-hidden shadow-2xl"
              />
            </aside>
          </div>
        </div>
      </section>

      {/* Reviews Section */}
      <section className="py-20 bg-beige/30" aria-labelledby="reviews-heading">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <header className="text-center mb-16">
            <h2 id="reviews-heading" className="text-3xl md:text-4xl font-playfair font-bold text-navy mb-6">
              Guest Reviews
            </h2>
            <p className="text-lg text-navy/70 max-w-2xl mx-auto">
              See what our guests are saying about their stay at Stay by the Sea.
            </p>
          </header>

          <div className="text-center py-16 bg-white rounded-2xl shadow-lg">
            <Star className="h-16 w-16 text-navy/30 mx-auto mb-6" />
            <h3 className="text-2xl font-playfair font-semibold text-navy mb-3">
              Reviews Coming Soon
            </h3>
            <p className="text-navy/60 mb-8 max-w-md mx-auto">
              We're setting up our review system. Check back soon to see what our guests are saying!
            </p>
          </div>

          <div className="text-center mt-12">
            <Link href="/reviews">
              <Button className="bg-coral hover:bg-coral/90 text-white px-8 py-4 text-lg rounded-2xl shadow-lg hover:shadow-xl transition-all">
                <PenSquare className="h-5 w-5 mr-2" />
                Write a Review
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 bg-white" aria-labelledby="faq-heading">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <header className="text-center mb-16">
            <h2 id="faq-heading" className="text-3xl md:text-4xl font-playfair font-bold text-navy mb-6">
              Frequently Asked Questions
            </h2>
            <p className="text-lg text-navy/70 max-w-2xl mx-auto">
              Find answers to common questions about your stay at Stay by the Sea.
            </p>
          </header>

          <Accordion type="single" collapsible className="space-y-4">
            {FAQ_DATA.map((faq, index) => (
              <AccordionItem key={index} value={`item-${index}`} className="border border-beige/30 rounded-2xl px-6">
                <AccordionTrigger className="text-left font-semibold text-navy hover:text-teal py-6">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-navy/70 pb-6">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>

          <div className="text-center mt-12">
            <p className="text-navy/70 mb-6">
              Have more questions? We're here to help!
            </p>
            <Link href="/contact">
              <Button className="btn-secondary">
                Contact Us
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-navy text-white" aria-labelledby="cta-heading">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 id="cta-heading" className="text-3xl md:text-4xl font-playfair font-bold mb-4">
            Ready for Your Seaside Getaway?
          </h2>
          <div className="inline-flex items-center gap-2 bg-coral/20 text-beige px-6 py-3 rounded-full text-base font-semibold mb-6">
            <span className="text-2xl">💰</span>
            <span>Save 5% when you book directly on our website</span>
          </div>
          <p className="text-xl text-beige mb-8 max-w-2xl mx-auto">
            Book your luxury accommodation today and create unforgettable memories by the sea.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link href="/book">
              <Button className="bg-coral hover:bg-coral/90 text-white px-10 py-4 text-lg rounded-2xl relative">
                Check Availability
                <span className="absolute -top-2 -right-2 bg-white text-coral px-2 py-1 rounded-full text-xs font-bold">
                  -5%
                </span>
              </Button>
            </Link>
            <Link href="/contact">
              <Button variant="outline" className="border-beige text-beige hover:bg-beige hover:text-navy px-8 py-4 text-lg rounded-2xl">
                Ask a Question
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}