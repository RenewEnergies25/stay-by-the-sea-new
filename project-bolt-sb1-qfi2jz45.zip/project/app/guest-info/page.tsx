import type { Metadata } from 'next';
import { Hero } from '@/components/ui/Hero';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { SEED_CONTENT, GALLERY_IMAGES } from '@/data/seed';
import { PROPERTY_CONFIG } from '@/lib/constants';
import Link from 'next/link';
import { Wifi, Car, Key, Clock, Phone, MapPin, Coffee, Utensils } from 'lucide-react';

export const metadata: Metadata = {
  title: 'Guest Information | Everything You Need to Know',
  description: 'Essential information for your stay at Stay by the Sea. Check-in details, Wi-Fi, parking, amenities, and local recommendations.',
  robots: {
    index: false,
    follow: false,
  },
};

export default function GuestInfoPage() {
  return (
    <>
      {/* Hero Section */}
      <Hero
        title="Guest Information"
        subtitle="Everything you need for a perfect stay"
        backgroundImage={GALLERY_IMAGES[0].src}
        showCTAs={false}
        height="medium"
      />

      {/* Check-in Information */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-playfair font-bold text-navy mb-6">
              Check-in & Access
            </h2>
            <p className="text-lg text-navy/70 max-w-2xl mx-auto">
              Your arrival and access information for Stay by the Sea
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center space-x-3">
                  <Clock className="h-6 w-6 text-teal" />
                  <span>Check-in Times</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-navy/70">{SEED_CONTENT.guestInfo.checkIn}</p>
                <div className="bg-teal/10 p-4 rounded-xl">
                  <p className="text-sm font-medium text-teal">
                    <strong>Check-in:</strong> 4:00 PM onwards<br />
                    <strong>Check-out:</strong> 11:00 AM
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center space-x-3">
                  <Key className="h-6 w-6 text-coral" />
                  <span>Property Access</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-navy/70">
                  Self check-in with door codes provided 24 hours before arrival via SMS and email.
                </p>
                <div className="bg-coral/10 p-4 rounded-xl">
                  <p className="text-sm font-medium text-coral">
                    Door codes and detailed instructions will be sent to you automatically.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Essential Information */}
      <section className="py-20 bg-beige/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-playfair font-bold text-navy mb-6">
              Essential Information
            </h2>
            <p className="text-lg text-navy/70 max-w-2xl mx-auto">
              Important details for your comfort and convenience
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center space-x-3">
                  <Wifi className="h-6 w-6 text-teal" />
                  <span>Wi-Fi Access</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-navy/70 mb-4">{SEED_CONTENT.guestInfo.wifi}</p>
                <div className="bg-teal/10 p-3 rounded-lg">
                  <p className="text-sm font-mono text-teal">Network: StayByTheSea_Guest</p>
                </div>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center space-x-3">
                  <Car className="h-6 w-6 text-navy" />
                  <span>Parking</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-navy/70">{SEED_CONTENT.guestInfo.parking}</p>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center space-x-3">
                  <Phone className="h-6 w-6 text-coral" />
                  <span>Emergency Contact</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <p className="text-navy/70">For urgent matters during your stay:</p>
                <a
                  href={`tel:${PROPERTY_CONFIG.contact.phone}`}
                  className="block font-semibold text-coral hover:text-coral/80"
                >
                  {PROPERTY_CONFIG.contact.phone}
                </a>
                <p className="text-sm text-navy/60">Available 24/7 for emergencies</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Property Amenities */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-playfair font-bold text-navy mb-6">
              What's Provided
            </h2>
            <p className="text-lg text-navy/70 max-w-2xl mx-auto">
              Everything you need for a comfortable stay is included
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center space-x-3">
                  <Coffee className="h-6 w-6 text-teal" />
                  <span>Kitchen & Dining</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <ul className="space-y-2 text-navy/70">
                  <li>• Fully equipped modern kitchen</li>
                  <li>• Coffee machine and tea facilities</li>
                  <li>• Dishwasher and washing machine</li>
                  <li>• Basic cooking essentials provided</li>
                  <li>• Dining area for group meals</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center space-x-3">
                  <Utensils className="h-6 w-6 text-coral" />
                  <span>Comfort & Convenience</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <ul className="space-y-2 text-navy/70">
                  <li>• Fresh linens and towels for all guests</li>
                  <li>• Air conditioning in every bedroom</li>
                  <li>• Underfloor heating throughout</li>
                  <li>• Smart TVs in all bedrooms and living areas</li>
                  <li>• Basic toiletries and cleaning supplies</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Local Recommendations */}
      <section className="py-20 bg-beige/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-playfair font-bold text-navy mb-6">
              Local Recommendations
            </h2>
            <p className="text-lg text-navy/70 max-w-2xl mx-auto">
              Our favorite spots near Stay by the Sea
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="text-teal">Dining Nearby</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="space-y-4">
                  <div>
                    <h4 className="font-semibold text-navy">Marco's New York Italian</h4>
                    <p className="text-sm text-navy/70">Comfort food and fine dining blend</p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-navy">Le Carter Blanche</h4>
                    <p className="text-sm text-navy/70">At The Chatwal Boutique Hotel</p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-navy">McDonald's</h4>
                    <p className="text-sm text-navy/70">Just 4 minutes walk for quick bites</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="text-coral">Must-Visit Attractions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="space-y-4">
                  <div>
                    <h4 className="font-semibold text-navy">Blackpool Pleasure Beach</h4>
                    <p className="text-sm text-navy/70">15 minute walk to thrilling rides</p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-navy">South Pier</h4>
                    <p className="text-sm text-navy/70">5 minute walk to amusements and views</p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-navy">Blackpool Tower</h4>
                    <p className="text-sm text-navy/70">20 minute walk to iconic landmark</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-20 bg-navy text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-playfair font-bold mb-6">
            Need Assistance?
          </h2>
          <p className="text-xl text-beige mb-8 max-w-2xl mx-auto">
            We're here to help make your stay perfect. Don't hesitate to reach out with any questions.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <a href={`tel:${PROPERTY_CONFIG.contact.phone}`}>
              <Button className="bg-coral hover:bg-coral/90 text-white px-10 py-4 text-lg rounded-2xl">
                <Phone className="h-5 w-5 mr-2" />
                Call Us
              </Button>
            </a>
            <Link href="/contact">
              <Button variant="outline" className="border-beige text-beige hover:bg-beige hover:text-navy px-8 py-4 text-lg rounded-2xl">
                <MapPin className="h-5 w-5 mr-2" />
                Contact Page
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}