import { PROPERTY_CONFIG, AMENITIES, ATTRACTIONS } from '@/lib/constants';

const baseUrl = process.env.NEXT_PUBLIC_PROPERTY_URL || 'https://example.com';

export function getOrganizationSchema() {
  return {
    '@context': 'https://schema.org',
    '@type': 'Organization',
    name: 'Stay by the Sea - Blackpool',
    url: baseUrl,
    logo: `${baseUrl}/logo.png`,
    sameAs: [
      'https://www.facebook.com/staybythesea',
      'https://www.instagram.com/staybythesea',
    ],
    contactPoint: {
      '@type': 'ContactPoint',
      telephone: PROPERTY_CONFIG.contact.phone,
      contactType: 'customer service',
      email: PROPERTY_CONFIG.contact.email,
      availableLanguage: ['English', 'Spanish', 'French', 'German'],
    },
  };
}

export function getAccommodationSchema(locale: string = 'en') {
  return {
    '@context': 'https://schema.org',
    '@type': 'Accommodation',
    '@id': `${baseUrl}#accommodation`,
    name: 'Stay by the Sea - Blackpool',
    description: 'Luxury holiday rental accommodation for up to 14 guests in Blackpool\'s South Shore. Features 7 double beds, air conditioning, underfloor heating, and private parking.',
    url: baseUrl,
    image: [
      'https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080',
      'https://images.pexels.com/photos/271618/pexels-photo-271618.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080',
      'https://images.pexels.com/photos/1454806/pexels-photo-1454806.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080',
    ],
    address: {
      '@type': 'PostalAddress',
      streetAddress: process.env.NEXT_PUBLIC_ADDRESS_LINE_1,
      addressLocality: process.env.NEXT_PUBLIC_ADDRESS_CITY || 'Blackpool',
      addressRegion: 'Lancashire',
      postalCode: process.env.NEXT_PUBLIC_ADDRESS_POSTCODE,
      addressCountry: 'GB',
    },
    geo: {
      '@type': 'GeoCoordinates',
      latitude: PROPERTY_CONFIG.coordinates.lat,
      longitude: PROPERTY_CONFIG.coordinates.lng,
    },
    telephone: PROPERTY_CONFIG.contact.phone,
    email: PROPERTY_CONFIG.contact.email,
    amenityFeature: AMENITIES.map(amenity => ({
      '@type': 'LocationFeatureSpecification',
      name: amenity.label,
      value: true,
    })),
    numberOfRooms: 7,
    numberOfBedrooms: 7,
    numberOfBathroomsTotal: 2,
    occupancy: {
      '@type': 'QuantitativeValue',
      maxValue: 14,
      unitText: 'guests',
    },
    floorSize: {
      '@type': 'QuantitativeValue',
      value: 250,
      unitCode: 'MTK',
    },
    petsAllowed: false,
    smokingAllowed: false,
    checkinTime: '15:00',
    checkoutTime: '10:00',
    priceRange: '££££',
    starRating: {
      '@type': 'Rating',
      ratingValue: 5,
      bestRating: 5,
    },
    inLanguage: locale,
  };
}

export function getBreadcrumbSchema(items: Array<{ name: string; url: string }>) {
  return {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: items.map((item, index) => ({
      '@type': 'ListItem',
      position: index + 1,
      name: item.name,
      item: `${baseUrl}${item.url}`,
    })),
  };
}

export function getFAQSchema(faqs: Array<{ question: string; answer: string }>) {
  return {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: faqs.map((faq) => ({
      '@type': 'Question',
      name: faq.question,
      acceptedAnswer: {
        '@type': 'Answer',
        text: faq.answer,
      },
    })),
  };
}

export function getPlaceSchema() {
  return {
    '@context': 'https://schema.org',
    '@type': 'TouristAttraction',
    name: 'Stay by the Sea - Blackpool',
    description: 'Prime location in Blackpool\'s South Shore with easy access to all major attractions',
    geo: {
      '@type': 'GeoCoordinates',
      latitude: PROPERTY_CONFIG.coordinates.lat,
      longitude: PROPERTY_CONFIG.coordinates.lng,
    },
    address: {
      '@type': 'PostalAddress',
      addressLocality: 'Blackpool',
      addressRegion: 'Lancashire',
      addressCountry: 'GB',
    },
    touristType: ['Families', 'Groups', 'Couples'],
    nearbyAttraction: ATTRACTIONS.map((attraction) => ({
      '@type': 'TouristAttraction',
      name: attraction.name,
      distance: attraction.distance,
    })),
  };
}

export function getVideoSchema(videoUrl: string, title: string, description: string) {
  return {
    '@context': 'https://schema.org',
    '@type': 'VideoObject',
    name: title,
    description: description,
    thumbnailUrl: 'https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080',
    contentUrl: videoUrl,
    uploadDate: new Date().toISOString(),
    duration: 'PT30S',
    inLanguage: 'en',
  };
}

export function getHowToSchema() {
  return {
    '@context': 'https://schema.org',
    '@type': 'HowTo',
    name: 'How to Book Stay by the Sea in Blackpool',
    description: 'Step-by-step guide to booking your luxury holiday rental at Stay by the Sea',
    step: [
      {
        '@type': 'HowToStep',
        position: 1,
        name: 'Check Availability',
        text: 'Visit the booking page and select your desired dates to see live availability',
        url: `${baseUrl}/book`,
      },
      {
        '@type': 'HowToStep',
        position: 2,
        name: 'Review Property Details',
        text: 'Explore the property amenities, photos, and location information',
        url: `${baseUrl}/the-property`,
      },
      {
        '@type': 'HowToStep',
        position: 3,
        name: 'Complete Booking',
        text: 'Enter your details and complete secure payment via Stripe or PayPal',
        url: `${baseUrl}/book`,
      },
      {
        '@type': 'HowToStep',
        position: 4,
        name: 'Receive Confirmation',
        text: 'Get instant email confirmation with check-in details and door code',
      },
    ],
    totalTime: 'PT5M',
    inLanguage: 'en',
  };
}

export function getImageObjectSchema(imageUrl: string, caption: string) {
  return {
    '@context': 'https://schema.org',
    '@type': 'ImageObject',
    contentUrl: imageUrl,
    caption: caption,
    license: `${baseUrl}/privacy-policy`,
    acquireLicensePage: `${baseUrl}/contact`,
    creditText: 'Stay by the Sea - Blackpool',
    creator: {
      '@type': 'Organization',
      name: 'Stay by the Sea',
    },
    copyrightNotice: '© Stay by the Sea. All rights reserved.',
  };
}

export function getProductSchema() {
  return {
    '@context': 'https://schema.org',
    '@type': 'Product',
    name: 'Stay by the Sea Holiday Rental - Blackpool',
    description: 'Luxury 7-bedroom holiday rental for 14 guests in Blackpool with air conditioning, private parking, and modern amenities',
    image: [
      'https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080',
      'https://images.pexels.com/photos/271618/pexels-photo-271618.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080',
    ],
    brand: {
      '@type': 'Brand',
      name: 'Stay by the Sea',
    },
    offers: {
      '@type': 'AggregateOffer',
      priceCurrency: 'GBP',
      lowPrice: '300',
      highPrice: '800',
      offerCount: '365',
      availability: 'https://schema.org/InStock',
      url: `${baseUrl}/book`,
      priceValidUntil: new Date(new Date().setFullYear(new Date().getFullYear() + 1)).toISOString().split('T')[0],
    },
    aggregateRating: {
      '@type': 'AggregateRating',
      ratingValue: '4.9',
      reviewCount: '50',
      bestRating: '5',
      worstRating: '1',
    },
  };
}