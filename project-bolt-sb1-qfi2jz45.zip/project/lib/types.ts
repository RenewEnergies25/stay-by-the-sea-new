// Basic types for the application
export interface GalleryImage {
  src: string;
  alt: string;
  caption: string;
}

export interface Attraction {
  name: string;
  distance: string;
  walkTime: string;
  description: string;
  category: string;
  lat: number;
  lng: number;
}

export interface Amenity {
  id: string;
  label: string;
  icon: string;
}