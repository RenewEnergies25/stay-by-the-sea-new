import { 
  type Locale, 
  locales, 
  defaultLocale, 
  localeNames, 
  localeFlags 
} from '@/lib/locales';

export type { Locale };
export { locales, defaultLocale, localeNames, localeFlags };

const translationCache = new Map<string, Map<string, string>>();

export async function getTranslationsMap(locale: Locale, namespace: string = 'common'): Promise<Map<string, string>> {
  const cacheKey = `${locale}:${namespace}`;

  if (translationCache.has(cacheKey)) {
    return translationCache.get(cacheKey)!;
  }

  // Return empty translations map since we removed the database
  const translations = new Map<string, string>();
  translationCache.set(cacheKey, translations);
  return translations;
}

export async function getTranslation(
  key: string,
  locale: Locale = defaultLocale,
  namespace: string = 'common',
  fallback?: string
): Promise<string> {
  const translations = await getTranslationsMap(locale, namespace);
  return translations.get(key) || fallback || key;
}

export function isValidLocale(locale: string): locale is Locale {
  return locales.includes(locale as Locale);
}

export function getLocaleFromPathname(pathname: string): Locale {
  const segments = pathname.split('/').filter(Boolean);
  const firstSegment = segments[0];

  if (firstSegment && isValidLocale(firstSegment)) {
    return firstSegment;
  }

  return defaultLocale;
}

export function removeLocaleFromPathname(pathname: string): string {
  const segments = pathname.split('/').filter(Boolean);
  const firstSegment = segments[0];

  if (firstSegment && isValidLocale(firstSegment)) {
    return '/' + segments.slice(1).join('/');
  }

  return pathname;
}

export function addLocaleToPathname(pathname: string, locale: Locale): string {
  const cleanPath = removeLocaleFromPathname(pathname);
  return `/${locale}${cleanPath}`;
}