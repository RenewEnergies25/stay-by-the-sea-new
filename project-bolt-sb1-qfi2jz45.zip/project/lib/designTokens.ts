// lib/designTokens.ts (safe for client/server)
export const COLORS = {
  navy: '#0D1B2A',
  teal: '#1B998B',
  beige: '#E8E1D9',
  'off-white': '#F7F7F5',
  coral: '#FF6B6B',
} as const;

export const FONTS = {
  playfair: "'Playfair Display', serif",
  inter: "'Inter', sans-serif",
} as const;

export const RADII = { 
  lg: 'var(--radius)', 
  md: 'calc(var(--radius) - 2px)' 
} as const;

export const SPACING = {
  xs: '0.25rem',
  sm: '0.5rem',
  md: '1rem',
  lg: '1.5rem',
  xl: '2rem',
  '2xl': '3rem',
} as const;

export const BREAKPOINTS = {
  sm: '640px',
  md: '768px',
  lg: '1024px',
  xl: '1280px',
  '2xl': '1536px',
} as const;