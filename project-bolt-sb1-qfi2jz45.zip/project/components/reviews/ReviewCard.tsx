import { Card, CardContent } from '@/components/ui/card';
import { Star } from 'lucide-react';

interface Review {
  id: string;
  guest_name: string;
  guest_email: string | null;
  rating: number;
  review_text: string;
  status: 'pending' | 'approved' | 'rejected';
  is_featured: boolean;
  created_at: string;
  approved_at: string | null;
  updated_at: string | null;
  ip_address: string | null;
}

interface ReviewCardProps {
  review: Review;
  featured?: boolean;
}

export function ReviewCard({ review, featured = false }: ReviewCardProps) {
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-GB', {
      month: 'long',
      year: 'numeric',
    });
  };

  return (
    <Card
      className={`border-0 shadow-lg hover:shadow-xl transition-shadow h-full ${
        featured ? 'border-2 border-coral' : ''
      }`}
    >
      <CardContent className="p-6">
        {featured && (
          <div className="mb-4">
            <span className="inline-block bg-coral text-white text-xs font-bold px-3 py-1 rounded-full">
              FEATURED REVIEW
            </span>
          </div>
        )}

        <div className="flex items-center gap-1 mb-4">
          {[...Array(5)].map((_, index) => (
            <Star
              key={index}
              className={`h-5 w-5 ${
                index < review.rating
                  ? 'fill-coral text-coral'
                  : 'text-gray-300'
              }`}
            />
          ))}
        </div>

        <p className="text-navy/80 leading-relaxed mb-4 italic">
          "{review.review_text}"
        </p>

        <div className="flex items-center justify-between pt-4 border-t border-beige/30">
          <div>
            <p className="font-semibold text-navy">{review.guest_name}</p>
            <p className="text-sm text-navy/60">
              {formatDate(review.created_at)}
            </p>
          </div>
          {review.rating === 5 && (
            <div className="flex items-center gap-1 text-coral">
              <Star className="h-4 w-4 fill-coral" />
              <span className="text-sm font-semibold">5 Stars</span>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}