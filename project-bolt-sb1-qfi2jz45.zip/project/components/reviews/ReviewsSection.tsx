'use client';

import { useEffect, useState, useCallback } from 'react';
import { ReviewCard } from './ReviewCard';
import { Button } from '@/components/ui/button';
import { Star, ChevronLeft, ChevronRight } from 'lucide-react';
import Link from 'next/link';

// Mock review data since we removed the database
const mockReviews = [
  {
    id: '1',
    guest_name: 'Sarah Johnson',
    guest_email: 'sarah@example.com',
    rating: 5,
    review_text: 'Amazing stay! The property was exactly as described and the location was perfect. The air conditioning was a lifesaver during the hot summer days, and having private parking made everything so convenient.',
    status: 'approved' as const,
    is_featured: true,
    created_at: new Date().toISOString(),
    approved_at: new Date().toISOString(),
    ip_address: '192.168.1.1',
    updated_at: new Date().toISOString()
  },
  {
    id: '2',
    guest_name: 'Michael Brown',
    guest_email: 'michael@example.com',
    rating: 5,
    review_text: 'Wonderful accommodation with all the amenities we needed. The property is spotless and the beds are incredibly comfortable. Walking distance to everything we wanted to see in Blackpool.',
    status: 'approved' as const,
    is_featured: false,
    created_at: new Date().toISOString(),
    approved_at: new Date().toISOString(),
    ip_address: '192.168.1.2',
    updated_at: new Date().toISOString()
  },
  {
    id: '3',
    guest_name: 'Emma Wilson',
    guest_email: 'emma@example.com',
    rating: 5,
    review_text: 'Perfect for our family group of 12. Everyone had their own comfortable bed and the kitchen was well-equipped for cooking meals. The location is unbeatable - so close to the beach and attractions.',
    status: 'approved' as const,
    is_featured: false,
    created_at: new Date().toISOString(),
    approved_at: new Date().toISOString(),
    ip_address: '192.168.1.3',
    updated_at: new Date().toISOString()
  }
];

interface ReviewsSectionProps {
  limit?: number;
  showViewAll?: boolean;
  featuredOnly?: boolean;
}

export function ReviewsSection({
  limit = 3,
  showViewAll = true,
  featuredOnly = false,
}: ReviewsSectionProps) {
  const [reviews, setReviews] = useState<typeof mockReviews>([]);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({ average: 4.9, total: 3 });
  const [currentIndex, setCurrentIndex] = useState(0);

  const fetchReviews = useCallback(async () => {
    // Simulate loading delay
    setTimeout(() => {
      let filteredData = mockReviews;
      
      if (featuredOnly) {
        filteredData = filteredData.filter(review => review.is_featured);
      }
      
      if (limit) {
        filteredData = filteredData.slice(0, limit);
      }

      setReviews(filteredData);
      setLoading(false);
    }, 500);
  }, [limit, featuredOnly]);

  useEffect(() => {
    fetchReviews();
  }, [fetchReviews]);

  const nextReview = () => {
    setCurrentIndex((prev) => (prev + 1) % reviews.length);
  };

  const prevReview = () => {
    setCurrentIndex((prev) => (prev - 1 + reviews.length) % reviews.length);
  };

  if (loading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {[...Array(limit)].map((_, i) => (
          <div
            key={i}
            className="bg-gray-100 rounded-2xl animate-pulse h-64"
          />
        ))}
      </div>
    );
  }

  if (reviews.length === 0) {
    return (
      <div className="text-center py-16 bg-beige/20 rounded-2xl">
        <Star className="h-16 w-16 text-navy/30 mx-auto mb-6" />
        <h3 className="text-2xl font-playfair font-semibold text-navy mb-3">
          No reviews yet
        </h3>
        <p className="text-navy/60 mb-8 max-w-md mx-auto">
          Be the first to share your experience and help future guests discover what makes this property special!
        </p>
        <Link href="/reviews">
          <Button className="bg-coral hover:bg-coral/90 text-white">
            Write a Review
          </Button>
        </Link>
      </div>
    );
  }

  return (
    <div>
      {stats.total > 0 && (
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-3 bg-white rounded-2xl px-8 py-4 shadow-lg">
            <div className="flex items-center gap-1">
              {[...Array(5)].map((_, index) => (
                <Star
                  key={index}
                  className={`h-6 w-6 ${
                    index < Math.round(stats.average)
                      ? 'fill-coral text-coral'
                      : 'text-gray-300'
                  }`}
                />
              ))}
            </div>
            <div className="border-l border-beige/30 pl-3">
              <p className="text-2xl font-bold text-navy">
                {stats.average.toFixed(1)}
              </p>
              <p className="text-sm text-navy/60">
                {stats.total} {stats.total === 1 ? 'review' : 'reviews'}
              </p>
            </div>
          </div>
        </div>
      )}

      {limit === 1 && reviews.length > 1 ? (
        <div className="relative">
          <div className="overflow-hidden">
            <ReviewCard review={reviews[currentIndex]} />
          </div>
          {reviews.length > 1 && (
            <div className="flex justify-center gap-4 mt-6">
              <Button
                onClick={prevReview}
                variant="outline"
                size="icon"
                className="rounded-full"
                aria-label="Previous review"
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <div className="flex items-center gap-2">
                {reviews.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentIndex(index)}
                    className={`w-2 h-2 rounded-full transition-all ${
                      index === currentIndex
                        ? 'bg-coral w-8'
                        : 'bg-navy/20'
                    }`}
                    aria-label={`Go to review ${index + 1}`}
                  />
                ))}
              </div>
              <Button
                onClick={nextReview}
                variant="outline"
                size="icon"
                className="rounded-full"
                aria-label="Next review"
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {reviews.map((review) => (
            <ReviewCard key={review.id} review={review} featured={review.is_featured} />
          ))}
        </div>
      )}

      {showViewAll && reviews.length >= limit && (
        <div className="text-center mt-12">
          <Link href="/reviews">
            <Button variant="outline" className="btn-secondary">
              View All Reviews
            </Button>
          </Link>
        </div>
      )}
    </div>
  );
}