'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Star } from 'lucide-react';

export function ReviewForm() {
  const [rating, setRating] = useState(0);
  const [hoveredRating, setHoveredRating] = useState(0);
  const [guestName, setGuestName] = useState('');
  const [guestEmail, setGuestEmail] = useState('');
  const [reviewText, setReviewText] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [errorMessage, setErrorMessage] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (rating === 0) {
      setErrorMessage('Please select a rating');
      return;
    }

    if (reviewText.length < 10) {
      setErrorMessage('Review must be at least 10 characters long');
      return;
    }

    setIsSubmitting(true);
    setErrorMessage('');

    // Simulate form submission since we removed the backend
    setTimeout(() => {
      setSubmitStatus('success');
      setRating(0);
      setGuestName('');
      setGuestEmail('');
      setReviewText('');
      setIsSubmitting(false);

      setTimeout(() => {
        setSubmitStatus('idle');
      }, 5000);
    }, 1000);
  };

  return (
    <Card className="border-0 shadow-xl">
      <CardHeader>
        <CardTitle className="text-2xl font-playfair text-navy">
          Share Your Experience
        </CardTitle>
        <p className="text-navy/70">
          Help future guests by sharing your thoughts about your stay
        </p>
      </CardHeader>
      <CardContent>
        {submitStatus === 'success' ? (
          <div className="bg-teal/10 border border-teal/30 rounded-xl p-6 text-center">
            <div className="w-16 h-16 bg-teal/20 rounded-full mx-auto flex items-center justify-center mb-4">
              <Star className="h-8 w-8 text-teal" />
            </div>
            <h3 className="text-xl font-semibold text-navy mb-2">
              Thank You for Your Review!
            </h3>
            <p className="text-navy/70">
              Your review has been submitted and will be published after moderation.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-navy mb-2">
                Your Rating *
              </label>
              <div className="flex gap-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onClick={() => setRating(star)}
                    onMouseEnter={() => setHoveredRating(star)}
                    onMouseLeave={() => setHoveredRating(0)}
                    className="transition-transform hover:scale-110"
                    aria-label={`Rate ${star} stars`}
                  >
                    <Star
                      className={`h-10 w-10 ${
                        star <= (hoveredRating || rating)
                          ? 'fill-coral text-coral'
                          : 'text-gray-300'
                      }`}
                    />
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label htmlFor="guestName" className="block text-sm font-medium text-navy mb-2">
                Your Name *
              </label>
              <Input
                id="guestName"
                type="text"
                value={guestName}
                onChange={(e) => setGuestName(e.target.value)}
                placeholder="John Smith"
                required
                className="border-beige/30"
              />
            </div>

            <div>
              <label htmlFor="guestEmail" className="block text-sm font-medium text-navy mb-2">
                Email Address (Optional)
              </label>
              <Input
                id="guestEmail"
                type="email"
                value={guestEmail}
                onChange={(e) => setGuestEmail(e.target.value)}
                placeholder="john@example.com"
                className="border-beige/30"
              />
              <p className="text-xs text-navy/60 mt-1">
                We&apos;ll only use this to contact you about your review if needed
              </p>
            </div>

            <div>
              <label htmlFor="reviewText" className="block text-sm font-medium text-navy mb-2">
                Your Review *
              </label>
              <Textarea
                id="reviewText"
                value={reviewText}
                onChange={(e) => setReviewText(e.target.value)}
                placeholder="Tell us about your experience staying at our property..."
                required
                rows={6}
                className="border-beige/30 resize-none"
              />
              <p className="text-xs text-navy/60 mt-1">
                Minimum 10 characters
              </p>
            </div>

            {errorMessage && (
              <div className="bg-red-50 border border-red-200 rounded-lg p-3 text-sm text-red-600">
                {errorMessage}
              </div>
            )}

            <Button
              type="submit"
              disabled={isSubmitting}
              className="w-full bg-coral hover:bg-coral/90 text-white"
            >
              {isSubmitting ? 'Submitting...' : 'Submit Review'}
            </Button>

            <p className="text-xs text-navy/60 text-center">
              By submitting this review, you agree that it may be published on our website and promotional materials.
            </p>
          </form>
        )}
      </CardContent>
    </Card>
  );
}