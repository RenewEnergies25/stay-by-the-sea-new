'use client';

import { useEffect, useRef, useState } from 'react';

export function SmoobuBookingScript() {
  const containerRef = useRef<HTMLDivElement>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [hasError, setHasError] = useState(false);
  const scriptLoadedRef = useRef(false);

  useEffect(() => {
    if (scriptLoadedRef.current) return;

    const loadSmoobuScript = () => {
      if (typeof window === 'undefined') return;

      const scriptId = 'smoobu-booking-script';
      const existingScript = document.getElementById(scriptId);

      if (existingScript) {
        initializeSmoobu();
        return;
      }

      const script = document.createElement('script');
      script.id = scriptId;
      script.type = 'text/javascript';
      script.src = 'https://login.smoobu.com/js/Settings/BookingToolIframe.js';
      script.async = true;

      script.onload = () => {
        scriptLoadedRef.current = true;
        initializeSmoobu();
      };

      script.onerror = () => {
        console.error('Failed to load Smoobu booking script');
        setHasError(true);
        setIsLoading(false);
      };

      document.body.appendChild(script);
    };

    const initializeSmoobu = () => {
      const maxAttempts = 20;
      let attempts = 0;

      const checkAndInitialize = () => {
        if (typeof window !== 'undefined' && (window as any).BookingToolIframe) {
          try {
            (window as any).BookingToolIframe.initialize({
              url: 'https://login.smoobu.com/en/booking-tool/iframe/1435556',
              baseUrl: 'https://login.smoobu.com',
              target: '#apartmentIframeAll'
            });
            setIsLoading(false);
          } catch (error) {
            console.error('Failed to initialize Smoobu widget:', error);
            setHasError(true);
            setIsLoading(false);
          }
        } else if (attempts < maxAttempts) {
          attempts++;
          setTimeout(checkAndInitialize, 200);
        } else {
          console.error('Smoobu BookingToolIframe not available after maximum attempts');
          setHasError(true);
          setIsLoading(false);
        }
      };

      checkAndInitialize();
    };

    const timeoutId = setTimeout(loadSmoobuScript, 100);

    return () => {
      clearTimeout(timeoutId);
    };
  }, []);

  if (hasError) {
    return (
      <div className="min-h-[600px] flex flex-col items-center justify-center p-8 bg-beige/20 rounded-lg">
        <div className="text-center max-w-md">
          <div className="text-4xl mb-4">📅</div>
          <h3 className="text-xl font-semibold text-navy mb-3">
            Booking Widget Temporarily Unavailable
          </h3>
          <p className="text-navy/70 mb-6">
            We're having trouble loading the booking calendar. Please contact us directly to check availability and make a reservation.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <a
              href="tel:+447976015890"
              className="inline-flex items-center justify-center gap-2 bg-coral hover:bg-coral/90 text-white px-6 py-3 rounded-lg transition-colors"
            >
              📞 Call Us
            </a>
            <a
              href="mailto:gpfpropertiesltd@gmail.com"
              className="inline-flex items-center justify-center gap-2 border-2 border-navy/20 hover:border-coral hover:bg-coral/5 text-navy px-6 py-3 rounded-lg transition-colors"
            >
              ✉️ Email Us
            </a>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="relative min-h-[800px]">
      {isLoading && (
        <div className="absolute inset-0 flex items-center justify-center bg-white">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-coral mx-auto mb-4"></div>
            <p className="text-navy/70">Loading booking calendar...</p>
          </div>
        </div>
      )}
      <div
        id="apartmentIframeAll"
        ref={containerRef}
        className="w-full"
      />
    </div>
  );
}