'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X, Phone, Mail, MessageCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { PROPERTY_CONFIG } from '@/lib/constants';

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const pathname = usePathname();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navigation = [
    { name: 'Home', href: '/' },
    { name: 'The Property', href: '/the-property' },
    { name: 'Location', href: '/location' },
    { name: 'Book Now', href: '/book' },
    { name: 'Contact', href: '/contact' },
  ];

  return (
    <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
      isScrolled ? 'glass-effect shadow-lg' : 'bg-transparent'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4">
          <Link href="/" className="flex items-center space-x-2 focus-ring rounded-lg">
            <div className="text-2xl font-playfair font-bold text-navy">
              Stay by the Sea
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center space-x-8">
            {navigation.slice(0, -2).map((item) => {
              const isActive = pathname === item.href;
              return (
                <Link
                  key={item.name}
                  href={item.href}
                  aria-current={isActive ? 'page' : undefined}
                  className={`relative transition-all duration-200 focus-ring rounded-lg px-3 py-2 ${
                    isActive
                      ? 'text-teal font-semibold'
                      : 'text-navy font-medium hover:text-teal'
                  }`}
                >
                  {item.name}
                  {isActive && (
                    <motion.div
                      layoutId="activeNav"
                      className="absolute bottom-0 left-0 right-0 h-0.5 bg-teal rounded-full"
                      initial={false}
                      transition={{ type: 'spring', stiffness: 380, damping: 30 }}
                    />
                  )}
                  {!isActive && (
                    <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-teal rounded-full scale-x-0 group-hover:scale-x-100 transition-transform duration-200 origin-left" />
                  )}
                </Link>
              );
            })}
          </nav>

          {/* Desktop Contact & CTA */}
          <div className="hidden lg:flex items-center space-x-4">
            <div className="flex items-center space-x-2 text-sm text-navy">
              <Phone className="h-4 w-4" />
              <a href={`tel:${PROPERTY_CONFIG.contact.phone}`} className="hover:text-teal focus-ring rounded">
                Call Us
              </a>
            </div>
            <Link href="/book">
              <Button className="btn-primary">
                Book Now
              </Button>
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="lg:hidden p-2 rounded-lg focus-ring"
            aria-label="Toggle menu"
          >
            {isMenuOpen ? (
              <X className="h-6 w-6 text-navy" />
            ) : (
              <Menu className="h-6 w-6 text-navy" />
            )}
          </button>
        </div>

        {/* Mobile Navigation */}
        <AnimatePresence>
          {isMenuOpen && (
            <motion.div
              key="mobile-menu"
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="lg:hidden py-4 border-t border-navy/10"
            >
              <nav className="space-y-4">
                {navigation.map((item) => {
                  const isActive = pathname === item.href;
                  return (
                    <Link
                      key={item.name}
                      href={item.href}
                      onClick={() => setIsMenuOpen(false)}
                      aria-current={isActive ? 'page' : undefined}
                      className={`block px-3 py-2 rounded-lg transition-all duration-200 ${
                        isActive
                          ? 'text-teal bg-teal/10 font-semibold border-l-4 border-teal'
                          : 'text-navy font-medium hover:text-teal hover:bg-teal/5'
                      }`}
                    >
                      {item.name}
                    </Link>
                  );
                })}
                <div className="pt-4 space-y-3 border-t border-navy/10">
                  <a
                    href={`tel:${PROPERTY_CONFIG.contact.phone}`}
                    className="flex items-center space-x-3 px-3 py-2 text-navy hover:text-teal rounded-lg"
                  >
                    <Phone className="h-5 w-5" />
                    <span>Call Us</span>
                  </a>
                  <a
                    href={`mailto:${PROPERTY_CONFIG.contact.email}`}
                    className="flex items-center space-x-3 px-3 py-2 text-navy hover:text-teal rounded-lg"
                  >
                    <Mail className="h-5 w-5" />
                    <span>Email Us</span>
                  </a>
                  <a
                    href={PROPERTY_CONFIG.contact.whatsapp}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center space-x-3 px-3 py-2 text-navy hover:text-teal rounded-lg"
                  >
                    <MessageCircle className="h-5 w-5" />
                    <span>WhatsApp</span>
                  </a>
                </div>
              </nav>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </header>
  );
}