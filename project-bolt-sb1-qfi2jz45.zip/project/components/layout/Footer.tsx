import Link from 'next/link';
import { Phone, Mail, MapPin, MessageCircle } from 'lucide-react';
import { PROPERTY_CONFIG } from '@/lib/constants';

export function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-navy text-off-white pb-28 sm:pb-32">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand & Contact */}
          <div className="lg:col-span-2">
            <h3 className="text-2xl font-playfair font-bold mb-6">
              Stay by the Sea
            </h3>
            <p className="text-beige mb-6 max-w-md">
              Luxury seaside accommodation for up to 14 guests in the heart of Blackpool&apos;s South Shore. 
              Your perfect coastal getaway awaits.
            </p>
            <div className="space-y-3">
              <div className="flex items-center space-x-3">
                <MapPin className="h-5 w-5 text-coral flex-shrink-0" />
                <address className="not-italic text-beige">
                  {PROPERTY_CONFIG.address.line1}<br />
                  {PROPERTY_CONFIG.address.line2}<br />
                  {PROPERTY_CONFIG.address.city} {PROPERTY_CONFIG.address.postcode}
                </address>
              </div>
              <a
                href={`tel:${PROPERTY_CONFIG.contact.phone}`}
                className="flex items-center space-x-3 text-beige hover:text-coral transition-colors focus-ring rounded"
              >
                <Phone className="h-5 w-5 flex-shrink-0" />
                <span>{PROPERTY_CONFIG.contact.phone}</span>
              </a>
              <a
                href={`mailto:${PROPERTY_CONFIG.contact.email}`}
                className="flex items-center space-x-3 text-beige hover:text-coral transition-colors focus-ring rounded"
              >
                <Mail className="h-5 w-5 flex-shrink-0" />
                <span>{PROPERTY_CONFIG.contact.email}</span>
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-semibold text-lg mb-6">Quick Links</h4>
            <ul className="space-y-3">
              {[
                { name: 'Home', href: '/' },
                { name: 'The Property', href: '/the-property' },
                { name: 'Location', href: '/location' },
                { name: 'Book Now', href: '/book' },
                { name: 'Guest Information', href: '/guest-info' },
                { name: 'Contact', href: '/contact' },
              ].map((link) => (
                <li key={link.name}>
                  <Link
                    href={link.href}
                    className="text-beige hover:text-coral transition-colors focus-ring rounded"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Legal & Support */}
          <div>
            <h4 className="font-semibold text-lg mb-6">Legal & Support</h4>
            <ul className="space-y-3">
              <li>
                <Link
                  href="/privacy-policy"
                  className="text-beige hover:text-coral transition-colors focus-ring rounded"
                >
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link
                  href="/terms"
                  className="text-beige hover:text-coral transition-colors focus-ring rounded"
                >
                  Terms of Service
                </Link>
              </li>
              <li>
                <a
                  href={PROPERTY_CONFIG.contact.whatsapp}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center space-x-2 text-beige hover:text-coral transition-colors focus-ring rounded"
                >
                  <MessageCircle className="h-4 w-4" />
                  <span>WhatsApp Support</span>
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-beige/20 mt-12 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0 gap-4">
            <p className="text-beige text-sm text-center md:text-left">
              © {currentYear} {PROPERTY_CONFIG.name}. All rights reserved.
            </p>
            <p className="text-beige text-sm text-center md:text-left">
              Built and Maintained by <span className="text-coral font-medium">AiMindShift</span>
            </p>
            <p className="text-beige text-sm text-center md:text-right">
              Luxury holiday rental in Blackpool, UK
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}