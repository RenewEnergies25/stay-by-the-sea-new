'use client';

import { Button } from '@/components/ui/button';
import Link from 'next/link';
import { Calendar, Phone, Percent } from 'lucide-react';
import { useEffect, useRef, useState } from 'react';

interface HeroProps {
  title: string;
  subtitle?: string;
  description?: string;
  backgroundImage?: string;
  videoUrl?: string;
  showCTAs?: boolean;
  height?: 'full' | 'medium';
  showDiscountBadge?: boolean;
}

export function Hero({
  title,
  subtitle,
  description,
  backgroundImage,
  videoUrl,
  showCTAs = false,
  height = 'full',
  showDiscountBadge = false,
}: HeroProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isVideoLoaded, setIsVideoLoaded] = useState(false);
  const [videoError, setVideoError] = useState(false);
  const [isVideoAttempted, setIsVideoAttempted] = useState(false);

  useEffect(() => {
    if (videoRef.current && videoUrl && !videoError && !isVideoAttempted) {
      setIsVideoAttempted(true);

      const playPromise = videoRef.current.play();

      if (playPromise !== undefined) {
        playPromise
          .then(() => {
            // Video started successfully
          })
          .catch(() => {
            // Autoplay failed, fallback to background image
            setVideoError(true);
          });
      }
    }
  }, [videoUrl, videoError, isVideoAttempted]);

  const heightClasses = height === 'full' ? 'min-h-screen' : 'min-h-[60vh]';

  return (
    <section className={`relative ${heightClasses} flex items-center justify-center overflow-hidden`}>
      {backgroundImage && (
        <div
          className={`absolute inset-0 z-0 bg-cover bg-center transition-opacity duration-1000 ${
            isVideoLoaded && !videoError ? 'opacity-0' : 'opacity-100'
          }`}
          style={{ backgroundImage: `url(${backgroundImage})` }}
        />
      )}

      {videoUrl && !videoError && (
        <video
          ref={videoRef}
          autoPlay
          loop
          muted
          playsInline
          preload="auto"
          crossOrigin="anonymous"
          onLoadedData={() => {
            setIsVideoLoaded(true);
          }}
          onError={() => {
            setVideoError(true);
            setIsVideoLoaded(false);
          }}
          className="absolute inset-0 z-10 w-full h-full object-cover"
        >
          <source src={videoUrl} type="video/mp4" />
          Your browser does not support the video tag.
        </video>
      )}

      <div className="absolute inset-0 z-20 bg-gradient-to-b from-navy/60 via-navy/40 to-navy/70" />

      {showDiscountBadge && (
        <div className="absolute top-8 right-8 z-40 hidden md:block animate-pulse">
          <div className="bg-coral text-white px-6 py-3 rounded-full shadow-2xl transform rotate-6">
            <div className="flex items-center gap-2">
              <Percent className="h-5 w-5" />
              <span className="font-bold text-lg">Save 5% Direct</span>
            </div>
          </div>
        </div>
      )}

      <div className="relative z-30 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-white">
        <h1 className="text-4xl md:text-5xl lg:text-6xl font-playfair font-bold mb-6 animate-fade-in">
          {title}
        </h1>

        {subtitle && (
          <p className="text-lg md:text-xl lg:text-2xl text-beige mb-6 max-w-3xl mx-auto animate-fade-in-delay-1">
            {subtitle}
          </p>
        )}

        {description && (
          <p className="text-base md:text-lg text-white/90 mb-10 max-w-3xl mx-auto leading-relaxed animate-fade-in-delay-2">
            {description}
          </p>
        )}

        {showCTAs && (
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 animate-fade-in-delay-3">
            <Link href="/book">
              <Button className="bg-coral hover:bg-coral/90 text-white px-10 py-4 text-lg rounded-2xl shadow-xl hover:shadow-2xl transition-all">
                <Calendar className="h-5 w-5 mr-2" />
                Check Availability
              </Button>
            </Link>
            <Link href="/contact">
              <Button
                variant="outline"
                className="border-2 border-white text-white hover:bg-white hover:text-navy px-8 py-4 text-lg rounded-2xl shadow-xl hover:shadow-2xl transition-all"
              >
                <Phone className="h-5 w-5 mr-2" />
                Contact Us
              </Button>
            </Link>
          </div>
        )}
      </div>

      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce z-30">
        <div className="w-6 h-10 border-2 border-white/50 rounded-full flex items-start justify-center p-2">
          <div className="w-1 h-3 bg-white/50 rounded-full" />
        </div>
      </div>
    </section>
  );
}
