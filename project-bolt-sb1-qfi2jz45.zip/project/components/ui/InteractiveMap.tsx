'use client';

import { useEffect, useRef } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

interface Attraction {
  name: string;
  lat: number;
  lng: number;
  description?: string;
  distance?: string;
  walkTime?: string;
  category?: string;
}

interface InteractiveMapProps {
  position: [number, number];
  zoom?: number;
  attractions?: Attraction[];
  className?: string;
}

function InteractiveMap({
  position,
  zoom = 14,
  attractions = [],
  className = '',
}: InteractiveMapProps) {
  const mapRef = useRef<L.Map | null>(null);
  const mapContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!mapContainerRef.current || mapRef.current) return;

    const map = L.map(mapContainerRef.current).setView(position, zoom);
    mapRef.current = map;

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
      maxZoom: 19,
    }).addTo(map);

    const propertyIcon = L.divIcon({
      className: 'custom-property-marker',
      html: `
        <div class="relative">
          <div class="absolute -top-10 -left-5 w-10 h-10 bg-coral rounded-full flex items-center justify-center shadow-lg border-4 border-white">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
              <polyline points="9 22 9 12 15 12 15 22"></polyline>
            </svg>
          </div>
        </div>
      `,
      iconSize: [40, 40],
      iconAnchor: [20, 40],
    });

    L.marker(position, { icon: propertyIcon })
      .addTo(map)
      .bindPopup(`
        <div class="text-center p-2">
          <h3 class="font-bold text-navy mb-1">Stay by the Sea</h3>
          <p class="text-sm text-navy/70">Your luxury accommodation</p>
        </div>
      `);

    const attractionIcon = L.divIcon({
      className: 'custom-attraction-marker',
      html: `
        <div class="relative">
          <div class="absolute -top-8 -left-4 w-8 h-8 bg-teal rounded-full flex items-center justify-center shadow-md border-2 border-white">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
              <circle cx="12" cy="10" r="3"></circle>
            </svg>
          </div>
        </div>
      `,
      iconSize: [32, 32],
      iconAnchor: [16, 32],
    });

    attractions.forEach((attraction) => {
      if (attraction.lat && attraction.lng) {
        L.marker([attraction.lat, attraction.lng], { icon: attractionIcon })
          .addTo(map)
          .bindPopup(`
            <div class="p-2">
              <h4 class="font-bold text-navy mb-1">${attraction.name}</h4>
              ${attraction.distance ? `<p class="text-xs text-teal mb-1">${attraction.distance} • ${attraction.walkTime}</p>` : ''}
              ${attraction.description ? `<p class="text-sm text-navy/70">${attraction.description}</p>` : ''}
            </div>
          `);
      }
    });

    return () => {
      if (mapRef.current) {
        mapRef.current.remove();
        mapRef.current = null;
      }
    };
  }, [position, zoom, attractions]);

  return (
    <div className={`w-full aspect-square rounded-2xl overflow-hidden shadow-2xl ${className}`}>
      <div ref={mapContainerRef} className="w-full h-full" />
    </div>
  );
}

export { InteractiveMap };
export default InteractiveMap;
