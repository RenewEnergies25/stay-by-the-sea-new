import * as Icons from 'lucide-react';

interface AmenityPillProps {
  icon: string;
  label: string;
}

export function AmenityPill({ icon, label }: AmenityPillProps) {
  const IconComponent = (Icons as any)[icon];

  return (
    <div className="flex items-center space-x-3 px-6 py-4 bg-white rounded-2xl shadow-md hover:shadow-lg transition-all duration-300 border border-beige/20 hover:border-teal/30 group">
      {IconComponent && (
        <IconComponent className="h-5 w-5 text-teal group-hover:scale-110 transition-transform flex-shrink-0" />
      )}
      <span className="text-navy font-medium">{label}</span>
    </div>
  );
}
