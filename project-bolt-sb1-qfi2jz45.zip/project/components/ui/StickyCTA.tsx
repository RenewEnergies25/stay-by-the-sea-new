'use client';

import { Button } from '@/components/ui/button';
import Link from 'next/link';
import { Calendar, Phone, Percent } from 'lucide-react';
import { useEffect, useState } from 'react';

export function StickyCTA() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      const scrollPosition = window.scrollY;
      const windowHeight = window.innerHeight;
      const documentHeight = document.documentElement.scrollHeight;

      const footer = document.querySelector('footer');
      const footerTop = footer?.getBoundingClientRect().top ?? 0;

      const isScrolledEnough = scrollPosition > 400;
      const isFooterVisible = footerTop < windowHeight;

      setIsVisible(isScrolledEnough && !isFooterVisible);
    };

    window.addEventListener('scroll', handleScroll);
    handleScroll();
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  if (!isVisible) return null;

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 bg-white border-t border-beige/30 shadow-2xl animate-slide-up">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-center sm:text-left">
            <h3 className="font-playfair font-bold text-navy text-lg flex items-center gap-2 justify-center sm:justify-start">
              <span>Ready to Book?</span>
              <span className="inline-flex items-center gap-1 bg-coral text-white px-2 py-1 rounded-full text-xs font-bold">
                <Percent className="h-3 w-3" />
                5% OFF
              </span>
            </h3>
            <p className="text-navy/70 text-sm">Book directly and save 5% on your stay</p>
          </div>
          <div className="flex items-center gap-3">
            <Link href="/contact">
              <Button variant="outline" className="btn-secondary">
                <Phone className="h-4 w-4 mr-2" />
                Contact
              </Button>
            </Link>
            <Link href="/book">
              <Button className="btn-primary relative">
                <Calendar className="h-4 w-4 mr-2" />
                Book Now
                <span className="absolute -top-2 -right-2 bg-white text-coral px-2 py-0.5 rounded-full text-xs font-bold shadow-lg">
                  -5%
                </span>
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
