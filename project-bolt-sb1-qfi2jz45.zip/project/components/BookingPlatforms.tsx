'use client';

import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { PROPERTY_CONFIG } from '@/lib/constants';
import { ExternalLink, Star, CircleCheck as CheckCircle } from 'lucide-react';

interface BookingPlatformsProps {
  variant?: 'full' | 'badges';
  className?: string;
}

export function BookingPlatforms({ variant = 'full', className = '' }: BookingPlatformsProps) {
  const handlePlatformClick = (platform: 'smoobu' | 'airbnb' | 'booking_com', url: string) => {
    // Analytics tracking removed
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  if (variant === 'badges') {
    return (
      <div className={`flex flex-wrap items-center gap-3 ${className}`}>
        <span className="text-sm text-navy/70 font-medium">Also available on:</span>
        {PROPERTY_CONFIG.booking.airbnbUrl && (
          <button
            onClick={() => handlePlatformClick('airbnb', PROPERTY_CONFIG.booking.airbnbUrl)}
            className="inline-flex items-center gap-2 px-3 py-1.5 text-sm bg-white border border-beige/30 rounded-lg hover:border-coral/50 hover:bg-coral/5 transition-all"
            aria-label="View on Airbnb"
          >
            <Star className="h-4 w-4 text-coral" />
            <span className="font-medium text-navy">Airbnb</span>
            <ExternalLink className="h-3 w-3 text-navy/50" />
          </button>
        )}
        {PROPERTY_CONFIG.booking.bookingComUrl && (
          <button
            onClick={() => handlePlatformClick('booking_com', PROPERTY_CONFIG.booking.bookingComUrl)}
            className="inline-flex items-center gap-2 px-3 py-1.5 text-sm bg-white border border-beige/30 rounded-lg hover:border-teal/50 hover:bg-teal/5 transition-all"
            aria-label="View on Booking.com"
          >
            <CheckCircle className="h-4 w-4 text-teal" />
            <span className="font-medium text-navy">Booking.com</span>
            <ExternalLink className="h-3 w-3 text-navy/50" />
          </button>
        )}
      </div>
    );
  }

  return (
    <div className={className}>
      <div className="text-center mb-8">
        <h3 className="text-2xl font-playfair font-bold text-navy mb-3">
          Multiple Ways to Book
        </h3>
        <p className="text-navy/70 max-w-2xl mx-auto mb-4">
          Book directly through our secure system or find us on your preferred platform
        </p>
        <div className="inline-flex items-center gap-2 bg-coral/10 text-coral px-4 py-2 rounded-full text-sm font-semibold">
          <CheckCircle className="h-4 w-4" />
          <span>Save 5% when you book directly on our website</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="border-2 border-coral shadow-xl relative overflow-hidden">
          <div className="absolute top-4 right-4 bg-coral text-white px-3 py-1 rounded-full text-xs font-bold">
            SAVE 5%
          </div>
          <CardContent className="p-8 text-center">
            <div className="w-20 h-20 bg-coral/10 rounded-2xl mx-auto flex items-center justify-center mb-6">
              <CheckCircle className="h-10 w-10 text-coral" />
            </div>
            <h4 className="text-xl font-playfair font-bold text-navy mb-2">
              Direct Booking
            </h4>
            <div className="inline-block bg-coral text-white px-3 py-1 rounded-full text-xs font-bold mb-3">
              5% CHEAPER
            </div>
            <p className="text-navy/70 mb-6 text-sm">
              Book directly with us for the best rates, instant confirmation, and personalized service
            </p>
            <div className="space-y-2 mb-6 text-left">
              <div className="flex items-center gap-2 text-sm">
                <CheckCircle className="h-4 w-4 text-teal" />
                <span className="text-navy/80 font-semibold">5% cheaper than other platforms</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <CheckCircle className="h-4 w-4 text-teal" />
                <span className="text-navy/80">Best price guarantee</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <CheckCircle className="h-4 w-4 text-teal" />
                <span className="text-navy/80">Instant confirmation</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <CheckCircle className="h-4 w-4 text-teal" />
                <span className="text-navy/80">Direct communication</span>
              </div>
            </div>
            <Button className="w-full bg-coral hover:bg-coral/90 text-white">
              Book Now
            </Button>
          </CardContent>
        </Card>

        {PROPERTY_CONFIG.booking.airbnbUrl && (
          <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
            <CardContent className="p-8 text-center">
              <div className="w-20 h-20 bg-coral/10 rounded-2xl mx-auto flex items-center justify-center mb-6">
                <Star className="h-10 w-10 text-coral" />
              </div>
              <h4 className="text-xl font-playfair font-bold text-navy mb-3">
                Airbnb
              </h4>
              <p className="text-navy/70 mb-6 text-sm">
                Book through Airbnb with their trusted platform and host guarantee
              </p>
              <div className="mb-6 h-16 flex items-center justify-center">
                <span className="text-sm text-navy/60">Verified Listing</span>
              </div>
              <Button
                onClick={() => handlePlatformClick('airbnb', PROPERTY_CONFIG.booking.airbnbUrl)}
                variant="outline"
                className="w-full border-navy/20 hover:border-coral hover:bg-coral/5"
              >
                View on Airbnb
                <ExternalLink className="ml-2 h-4 w-4" />
              </Button>
            </CardContent>
          </Card>
        )}

        {PROPERTY_CONFIG.booking.bookingComUrl && (
          <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
            <CardContent className="p-8 text-center">
              <div className="w-20 h-20 bg-teal/10 rounded-2xl mx-auto flex items-center justify-center mb-6">
                <CheckCircle className="h-10 w-10 text-teal" />
              </div>
              <h4 className="text-xl font-playfair font-bold text-navy mb-3">
                Booking.com
              </h4>
              <p className="text-navy/70 mb-6 text-sm">
                Reserve with the world&apos;s leading accommodation provider
              </p>
              <div className="mb-6 h-16 flex items-center justify-center">
                <span className="text-sm text-navy/60">Trusted Platform</span>
              </div>
              <Button
                onClick={() => handlePlatformClick('booking_com', PROPERTY_CONFIG.booking.bookingComUrl)}
                variant="outline"
                className="w-full border-navy/20 hover:border-teal hover:bg-teal/5"
              >
                View on Booking.com
                <ExternalLink className="ml-2 h-4 w-4" />
              </Button>
            </CardContent>
          </Card>
        )}
      </div>

      <div className="mt-8 text-center">
        <p className="text-sm text-navy/60">
          Same property, your choice of platform. We&apos;re committed to providing an excellent experience no matter how you book.
        </p>
        <p className="text-sm text-coral font-semibold mt-2">
          💡 Tip: Booking directly saves you 5% compared to third-party platforms
        </p>
      </div>
    </div>
  );
}