'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { X } from 'lucide-react';

export function CookieConsent() {
  const [showBanner, setShowBanner] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem('cookie_consent');
    if (!consent) {
      setShowBanner(true);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem('cookie_consent', 'accepted');
    setShowBanner(false);
  };

  const handleDecline = () => {
    localStorage.setItem('cookie_consent', 'declined');
    setShowBanner(false);
  };

  if (!showBanner) return null;

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-navy/95 backdrop-blur-sm text-white z-50 shadow-2xl">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex-1">
            <h3 className="text-lg font-semibold mb-2">We Value Your Privacy</h3>
            <p className="text-sm text-beige/90">
              We use cookies and analytics to improve your experience, track website usage, and understand booking behavior.
              By clicking &quot;Accept&quot;, you consent to our use of cookies.{' '}
              <a href="/privacy-policy" className="underline hover:text-coral">
                Learn more
              </a>
            </p>
          </div>
          <div className="flex items-center gap-3">
            <Button
              onClick={handleDecline}
              variant="outline"
              className="border-beige text-beige hover:bg-beige hover:text-navy"
            >
              Decline
            </Button>
            <Button
              onClick={handleAccept}
              className="bg-coral hover:bg-coral/90 text-white"
            >
              Accept
            </Button>
          </div>
          <button
            onClick={handleDecline}
            className="absolute top-4 right-4 md:relative md:top-0 md:right-0 text-beige hover:text-white"
            aria-label="Close cookie banner"
          >
            <X className="h-5 w-5" />
          </button>
        </div>
      </div>
    </div>
  );
}
